#!/bin/bash
echo "[*] Building with Ubuntu 20.04 base (GLIBC 2.31)..."
if ! command -v docker &> /dev/null; then
    echo "[!] Docker not installed. Run: sudo apt install docker.io -y"
    exit 1
fi

echo "[*] Building Docker image..."
docker build -t nsync-builder-2004 .

echo "[*] Running build inside container..."
docker run --rm -v "$(pwd):/worm_workspace" nsync-builder-2004

echo "[*] Build complete!"
echo "[*] Compatible: GLIBC >= 2.31, SSE2, AVX2, AVX512"
echo "[*] Output: AI_workspace/app.py"
