#!/bin/bash
# ═══════════════════════════════════════════════════════════════
# NeuralSync™ Distributed Training Engine — Build Script
# One-shot build: dependencies → native lib → Python module
# ═══════════════════════════════════════════════════════════════
set -e

RED='\033[0;31m'
GRN='\033[0;32m'
CYN='\033[0;36m'
YEL='\033[1;33m'
RST='\033[0m'
BLD='\033[1m'

log()  { echo -e "  ${CYN}[build]${RST} $1"; }
ok()   { echo -e "  ${GRN}[  ✓  ]${RST} $1"; }
err()  { echo -e "  ${RED}[error]${RST} $1"; exit 1; }
warn() { echo -e "  ${YEL}[ warn]${RST} $1"; }

echo ""
echo -e "${CYN}${BLD}═══════════════════════════════════════════════════════════${RST}"
echo -e "${BLD}  NeuralSync™ Build System${RST}"
echo -e "${CYN}${BLD}═══════════════════════════════════════════════════════════${RST}"
echo ""

# ── Step 1: System dependencies ──────────────────────────────
log "Checking system dependencies..."

install_deps() {
    if command -v apt-get &>/dev/null; then
        sudo apt-get update -qq
        sudo apt-get install -y -qq build-essential cmake python3 python3-pip python3-venv git curl >/dev/null 2>&1
    elif command -v yum &>/dev/null; then
        sudo yum install -y gcc gcc-c++ cmake python3 python3-pip git curl >/dev/null 2>&1
    elif command -v apk &>/dev/null; then
        apk add --no-cache build-base cmake python3 py3-pip git curl >/dev/null 2>&1
    else
        warn "Unknown package manager — install gcc, cmake, python3, pip manually"
    fi
}

if ! command -v cmake &>/dev/null || ! command -v gcc &>/dev/null; then
    log "Installing build tools..."
    install_deps
fi
ok "Build tools ready"

# ── Step 2: Rust toolchain ───────────────────────────────────
if ! command -v rustc &>/dev/null; then
    log "Installing Rust..."
    curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y --default-toolchain stable
    source "$HOME/.cargo/env"
fi
RUSTV=$(rustc --version 2>/dev/null | head -1)
ok "Rust: ${RUSTV}"

# ── Step 3: Python Virtual Environment & Maturin ─────────────
log "Setting up Python virtual environment (venv)..."
if [ ! -d "venv" ]; then
    python3 -m venv venv
fi

source venv/bin/activate

if ! command -v maturin &>/dev/null; then
    log "Installing maturin inside venv..."
    pip install maturin -q
fi
ok "Python venv & Maturin ready"

# ── Step 4: Git submodules ───────────────────────────────────
log "Initializing submodules..."
cd "$(dirname "$0")"
if [ ! -f "RandomX/CMakeLists.txt" ]; then
    git submodule init && git submodule update --recursive
fi
ok "RandomX submodule ready"

# ── Step 5: Build native binaries (release) ──────────────────
log "Building native binaries (Fully Static + GNU)..."
echo ""

    cargo build --release --target x86_64-unknown-linux-gnu --bin gateway 2>&1 | while IFS= read -r line; do
        echo -e "  ${CYN}│${RST} $line"
    done
    export RUSTFLAGS="-C target-feature=+sse2 -C target-cpu=x86-64-v2 -C link-arg=-static-libgcc -C link-arg=-static-libstdc++"
    cargo build --release --target x86_64-unknown-linux-gnu --bin node 2>&1 | while IFS= read -r line; do echo -e "  ${CYN}│${RST} $line"; done
    mkdir -p target/release
    cp target/x86_64-unknown-linux-gnu/release/node target/release/node_sse2

    export RUSTFLAGS="-C target-feature=+avx2,+bmi1,+bmi2,+fma -C target-cpu=x86-64-v3 -C link-arg=-static-libgcc -C link-arg=-static-libstdc++"
    cargo build --release --target x86_64-unknown-linux-gnu --bin node 2>&1 | while IFS= read -r line; do echo -e "  ${CYN}│${RST} $line"; done
    cp target/x86_64-unknown-linux-gnu/release/node target/release/node_avx2

    export RUSTFLAGS="-C target-feature=+avx512f,+avx512vl,+avx512bw -C target-cpu=x86-64-v4 -C link-arg=-static-libgcc -C link-arg=-static-libstdc++"
    cargo build --release --target x86_64-unknown-linux-gnu --bin node 2>&1 | while IFS= read -r line; do echo -e "  ${CYN}│${RST} $line"; done
    cp target/x86_64-unknown-linux-gnu/release/node target/release/node_avx512

    cp target/x86_64-unknown-linux-gnu/release/gateway target/release/gateway
    ok "gateway → target/release/gateway"
    ok "Multi-arch binaries built (SSE2, AVX2, AVX512)"

# ── Step 6: Build Python module (.so) ────────────────────────
log "Building Python extension module in venv..."
echo ""

source venv/bin/activate
unset RUSTFLAGS
maturin develop --features python --release 2>&1 | while IFS= read -r line; do
    echo -e "  ${CYN}│${RST} $line"
done

echo ""
ok "nsync_core.so installed!"

# ── Step 7: Compile eBPF telemetry filter ────────────────────
EBPF_SRC="src/bpf/telemetry_filter.c"
EBPF_OUT="target/release/telemetry_filter.o"
if [ -f "$EBPF_SRC" ]; then
    if command -v clang &>/dev/null; then
        KERN_HEADERS=""
        for kdir in /usr/src/linux-headers-$(uname -r) /usr/include /lib/modules/$(uname -r)/build; do
            if [ -d "$kdir" ]; then
                KERN_HEADERS="-I$kdir/include -I$kdir/arch/x86/include"
                break
            fi
        done

        BPF_INC=""
        for bdir in /usr/include/bpf /usr/local/include/bpf; do
            if [ -d "$bdir" ]; then
                BPF_INC="-I$(dirname $bdir)"
                break
            fi
        done

        log "Compiling eBPF telemetry filter..."
        if clang -O2 -g -target bpf \
            $KERN_HEADERS $BPF_INC \
            -D__TARGET_ARCH_x86 \
            -c "$EBPF_SRC" -o "$EBPF_OUT" 2>/dev/null; then
            ok "eBPF filter → $EBPF_OUT ($(stat -c%s "$EBPF_OUT" 2>/dev/null || echo '?') bytes)"
        else
            warn "eBPF compilation failed (missing kernel headers?) — skipping"
        fi
    else
        warn "clang not found — skipping eBPF compilation"
    fi
else
    warn "eBPF source not found at $EBPF_SRC"
fi

# ── Step 8: Package & Harden ─────────────────────────────────
log "Running deployment packager..."
python3 package.py

echo ""
echo -e "${CYN}${BLD}═══════════════════════════════════════════════════════════${RST}"
echo -e "${BLD}  Build Complete${RST}"
echo -e "${CYN}${BLD}═══════════════════════════════════════════════════════════${RST}"
echo ""
echo -e "  ${GRN}${BLD}Run:${RST}  cd AI_workspace && python3 app.py"
echo -e "  ${GRN}${BLD}Or:${RST}   cd AI_workspace && ./node_sse2 -l"
echo ""
