import sys
import asyncio
import time
import os

try:
    from cloakbrowser import launch_async
except ImportError:
    print("[!] cloakbrowser not installed. Run: pip3 install cloakbrowser")
    sys.exit(1)


CF_TEST_URLS = [
    {
        "name": "Cloudflare Turnstile Demo (Non-Interactive)",
        "url": "https://2captcha.com/demo/cloudflare-turnstile",
        "type": "turnstile",
    },
    {
        "name": "Cloudflare Challenge Page (Managed)",
        "url": "https://nopecha.com/captcha/turnstile",
        "type": "turnstile",
    },
    {
        "name": "BrowserScan Bot Detection",
        "url": "https://www.browserscan.net/bot-detection",
        "type": "bot_check",
    },
    {
        "name": "Bot Detection (incolumitas)",
        "url": "https://bot.incolumitas.com/",
        "type": "bot_check",
    },
    {
        "name": "DeviceAndBrowserInfo",
        "url": "https://deviceandbrowserinfo.com/info_device",
        "type": "bot_check",
    },
]


async def run_test(url_info, headless=True, proxy=None, screenshot_dir="screenshots"):
    os.makedirs(screenshot_dir, exist_ok=True)

    print(f"\n{'='*60}")
    print(f"[TEST] {url_info['name']}")
    print(f"[URL]  {url_info['url']}")
    print(f"{'='*60}")

    launch_kwargs = {
        "headless": headless,
        "humanize": True,
    }
    if proxy:
        launch_kwargs["proxy"] = proxy

    browser = None
    try:
        browser = await launch_async(**launch_kwargs)
        page = await browser.new_page()

        page.set_default_timeout(60000)

        print(f"[*] Navigating...")
        await page.goto(url_info["url"], wait_until="domcontentloaded")

        print(f"[*] Waiting 10s for page + challenges to load...")
        await asyncio.sleep(10)

        try:
            await page.wait_for_load_state("networkidle", timeout=30000)
        except Exception:
            print("[*] networkidle timeout, continuing anyway...")

        if url_info["type"] == "turnstile":
            print("[*] Looking for Turnstile iframe...")
            try:
                turnstile_frame = None
                for frame in page.frames:
                    if "challenges.cloudflare.com" in frame.url:
                        turnstile_frame = frame
                        break

                if turnstile_frame:
                    print("[*] Turnstile iframe found!")
                    checkbox = await turnstile_frame.query_selector('input[type="checkbox"]')
                    if checkbox:
                        print("[*] Clicking Turnstile checkbox...")
                        await checkbox.click()
                        await asyncio.sleep(5)
                    else:
                        body_el = await turnstile_frame.query_selector("body")
                        if body_el:
                            await body_el.click()
                            await asyncio.sleep(5)
                        print("[*] No checkbox found, clicked frame body")
                else:
                    print("[*] No Turnstile iframe detected, checking for widget...")
                    widget = await page.query_selector(".cf-turnstile")
                    if widget:
                        await widget.click()
                        await asyncio.sleep(5)
            except Exception as e:
                print(f"[!] Turnstile interaction error: {e}")

            await asyncio.sleep(3)

            try:
                token_el = await page.query_selector('input[name="cf-turnstile-response"]')
                if token_el:
                    token_val = await token_el.get_attribute("value")
                    if token_val and len(token_val) > 10:
                        print(f"[+] TURNSTILE TOKEN FOUND! Length: {len(token_val)}")
                        print(f"[+] Token prefix: {token_val[:50]}...")
                        print(f"[RESULT] PASS")
                    else:
                        print(f"[-] Token element found but empty/short")
                        print(f"[RESULT] UNCLEAR")
                else:
                    body_text = await page.inner_text("body")
                    body_lower = body_text.lower()
                    if "success" in body_lower or "passed" in body_lower or "verified" in body_lower:
                        print(f"[+] Page indicates success")
                        print(f"[RESULT] PASS")
                    elif "fail" in body_lower or "blocked" in body_lower or "denied" in body_lower:
                        print(f"[-] Page indicates failure")
                        print(f"[RESULT] FAIL")
                    else:
                        print(f"[?] No clear success/fail indicator")
                        print(f"[RESULT] MANUAL CHECK NEEDED")
            except Exception as e:
                print(f"[!] Result check error: {e}")
                print(f"[RESULT] ERROR")

        elif url_info["type"] == "bot_check":
            await asyncio.sleep(5)
            body_text = await page.inner_text("body")

            if "browserscan" in url_info["url"].lower():
                if "Normal" in body_text or "NORMAL" in body_text:
                    print(f"[+] BrowserScan: NORMAL detected")
                    print(f"[RESULT] PASS")
                elif "Bot" in body_text or "BOT" in body_text:
                    print(f"[-] BrowserScan: BOT detected")
                    print(f"[RESULT] FAIL")
                else:
                    print(f"[?] BrowserScan: unclear result")
                    print(f"[RESULT] MANUAL CHECK NEEDED")

            elif "incolumitas" in url_info["url"].lower():
                if "human" in body_text.lower():
                    print(f"[+] incolumitas: Human detected")
                    print(f"[RESULT] PASS")
                elif "bot" in body_text.lower():
                    print(f"[-] incolumitas: Bot detected")
                    print(f"[RESULT] FAIL")
                else:
                    print(f"[?] incolumitas: unclear")
                    print(f"[RESULT] MANUAL CHECK NEEDED")

            elif "deviceandbrowserinfo" in url_info["url"].lower():
                if "you are human" in body_text.lower():
                    print(f"[+] DeviceInfo: 'You are human!' detected")
                    print(f"[RESULT] PASS")
                elif "bot" in body_text.lower():
                    print(f"[-] DeviceInfo: Bot detected")
                    print(f"[RESULT] FAIL")
                else:
                    print(f"[?] DeviceInfo: unclear")
                    print(f"[RESULT] MANUAL CHECK NEEDED")
            else:
                print(f"[*] Body text (first 500 chars):")
                print(body_text[:500])
                print(f"[RESULT] MANUAL CHECK NEEDED")

        safe_name = url_info["name"].replace(" ", "_").replace("/", "_").replace("(", "").replace(")", "")
        screenshot_path = os.path.join(screenshot_dir, f"{safe_name}.png")
        await page.screenshot(path=screenshot_path, full_page=True)
        print(f"[*] Screenshot saved: {screenshot_path}")

        await page.close()
        return "completed"

    except Exception as e:
        print(f"[!] Test failed with error: {e}")
        print(f"[RESULT] ERROR")
        return f"error: {e}"
    finally:
        if browser:
            try:
                await browser.close()
            except:
                pass


async def main():
    print("=" * 60)
    print("  CloakBrowser - Cloudflare Turnstile & Bot Detection Test")
    print("=" * 60)

    headless = True
    proxy = None

    for arg in sys.argv[1:]:
        if arg == "--headed":
            headless = False
        elif arg.startswith("--proxy="):
            proxy = arg.split("=", 1)[1]
        elif arg == "--help":
            print(f"Usage: python3 {sys.argv[0]} [--headed] [--proxy=socks5://user:pass@host:port]")
            sys.exit(0)

    print(f"\n[*] Mode: {'headless' if headless else 'headed'}")
    print(f"[*] Proxy: {proxy or 'none'}")
    print(f"[*] Humanize: enabled")
    print(f"[*] Tests: {len(CF_TEST_URLS)}")

    results = []
    for url_info in CF_TEST_URLS:
        status = await run_test(url_info, headless=headless, proxy=proxy)
        results.append({"name": url_info["name"], "status": status})

    print(f"\n\n{'='*60}")
    print(f"  SUMMARY")
    print(f"{'='*60}")
    for r in results:
        icon = "[+]" if r["status"] == "completed" else "[!]"
        print(f"  {icon} {r['name']}: {r['status']}")
    print(f"\n[*] Screenshots in ./screenshots/")
    print(f"[*] Done.")


if __name__ == "__main__":
    asyncio.run(main())
