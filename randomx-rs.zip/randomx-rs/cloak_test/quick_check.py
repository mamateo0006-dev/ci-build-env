import sys
import asyncio
import os

try:
    from cloakbrowser import launch_async
except ImportError:
    print("[!] cloakbrowser not installed. Run: pip3 install cloakbrowser")
    sys.exit(1)


async def quick_test(proxy=None):
    print("[*] CloakBrowser Quick Stealth Check")
    print("=" * 50)

    launch_kwargs = {"headless": True, "humanize": True}
    if proxy:
        launch_kwargs["proxy"] = proxy

    browser = await launch_async(**launch_kwargs)
    page = await browser.new_page()

    await page.goto("about:blank")
    checks = {}

    checks["navigator.webdriver"] = await page.evaluate("() => navigator.webdriver")
    checks["navigator.plugins.length"] = await page.evaluate("() => navigator.plugins.length")
    checks["window.chrome"] = await page.evaluate("() => typeof window.chrome")
    checks["userAgent"] = await page.evaluate("() => navigator.userAgent")
    checks["languages"] = await page.evaluate("() => navigator.languages")
    checks["hardwareConcurrency"] = await page.evaluate("() => navigator.hardwareConcurrency")
    checks["deviceMemory"] = await page.evaluate("() => navigator.deviceMemory || 'N/A'")
    checks["platform"] = await page.evaluate("() => navigator.platform")
    checks["maxTouchPoints"] = await page.evaluate("() => navigator.maxTouchPoints")
    checks["webgl_vendor"] = await page.evaluate("""() => {
        try {
            const c = document.createElement('canvas');
            const gl = c.getContext('webgl');
            const ext = gl.getExtension('WEBGL_debug_renderer_info');
            return gl.getParameter(ext.UNMASKED_VENDOR_WEBGL);
        } catch(e) { return 'N/A'; }
    }""")
    checks["webgl_renderer"] = await page.evaluate("""() => {
        try {
            const c = document.createElement('canvas');
            const gl = c.getContext('webgl');
            const ext = gl.getExtension('WEBGL_debug_renderer_info');
            return gl.getParameter(ext.UNMASKED_RENDERER_WEBGL);
        } catch(e) { return 'N/A'; }
    }""")

    print(f"\n{'Property':<30} {'Value'}")
    print("-" * 70)

    webdriver_ok = checks["navigator.webdriver"] == False
    plugins_ok = checks["navigator.plugins.length"] > 0
    chrome_ok = checks["window.chrome"] == "object"
    ua_ok = "HeadlessChrome" not in str(checks["userAgent"])

    status = lambda ok: "[+]" if ok else "[-]"

    print(f"  {status(webdriver_ok)} navigator.webdriver      = {checks['navigator.webdriver']}")
    print(f"  {status(plugins_ok)} navigator.plugins.length = {checks['navigator.plugins.length']}")
    print(f"  {status(chrome_ok)} window.chrome            = {checks['window.chrome']}")
    print(f"  {status(ua_ok)} userAgent                = {checks['userAgent'][:80]}...")
    print(f"  [*] languages              = {checks['languages']}")
    print(f"  [*] hardwareConcurrency    = {checks['hardwareConcurrency']}")
    print(f"  [*] deviceMemory           = {checks['deviceMemory']}")
    print(f"  [*] platform               = {checks['platform']}")
    print(f"  [*] maxTouchPoints         = {checks['maxTouchPoints']}")
    print(f"  [*] WebGL vendor           = {checks['webgl_vendor']}")
    print(f"  [*] WebGL renderer         = {checks['webgl_renderer']}")

    passed = sum([webdriver_ok, plugins_ok, chrome_ok, ua_ok])
    total = 4
    print(f"\n[{'+'if passed==total else '!'}] Stealth basics: {passed}/{total} passed")

    await page.close()
    await browser.close()

    return passed == total


if __name__ == "__main__":
    proxy = None
    for arg in sys.argv[1:]:
        if arg.startswith("--proxy="):
            proxy = arg.split("=", 1)[1]
    asyncio.run(quick_test(proxy))
