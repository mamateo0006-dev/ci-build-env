#!/bin/bash
set -e

echo "[*] Installing Chromium shared library dependencies..."
apt-get update -qq
apt-get install -y -qq \
    libatk1.0-0 libatk-bridge2.0-0 libatspi2.0-0 \
    libcups2 libdrm2 libxkbcommon0 libxcomposite1 \
    libxdamage1 libxfixes3 libxrandr2 libgbm1 \
    libpango-1.0-0 libcairo2 \
    libwayland-client0 libnss3 libnspr4 \
    libglib2.0-0 libdbus-1-3 libx11-6 libx11-xcb1 \
    libxcb1 libxext6 libxtst6 \
    fonts-liberation fonts-noto-color-emoji \
    xvfb wget curl ca-certificates \
    python3 python3-pip \
    2>/dev/null

apt-get install -y -qq libasound2 2>/dev/null || apt-get install -y -qq libasound2t64 2>/dev/null || true

echo "[*] Installing cloakbrowser..."
pip3 install --break-system-packages cloakbrowser 2>/dev/null || pip3 install cloakbrowser

echo "[*] Done. Run: python3 cf_turnstile_test.py"
