import sys
import asyncio
import os

try:
    from cloakbrowser import launch_async
except ImportError:
    print("[!] cloakbrowser not installed. Run: pip3 install cloakbrowser")
    sys.exit(1)

async def google_login(email, password, headless=True, proxy=None):
    os.makedirs("screenshots", exist_ok=True)
    launch_kwargs = {
        "headless": headless,
        "humanize": True,
    }
    if proxy:
        launch_kwargs["proxy"] = proxy

    browser = await launch_async(**launch_kwargs)
    page = await browser.new_page()
    page.set_default_timeout(60000)

    try:
        print("[*] Navigating to Google Login...")
        await page.goto("https://accounts.google.com/", wait_until="networkidle")
        await page.screenshot(path="screenshots/1_login_page.png")

        print("[*] Entering email...")
        email_input = await page.wait_for_selector('input[type="email"]')
        await email_input.fill(email)
        await page.screenshot(path="screenshots/2_email_filled.png")

        print("[*] Clicking Next after email...")
        next_button = await page.wait_for_selector('#identifierNext')
        await next_button.click()
        
        await asyncio.sleep(5)
        await page.screenshot(path="screenshots/3_password_page.png")

        print("[*] Entering password...")
        password_input = await page.wait_for_selector('input[type="password"]')
        await password_input.fill(password)
        await page.screenshot(path="screenshots/4_password_filled.png")

        print("[*] Clicking Next after password...")
        next_pass_button = await page.wait_for_selector('#passwordNext')
        await next_pass_button.click()

        await asyncio.sleep(10)
        await page.screenshot(path="screenshots/5_login_result.png")

        current_url = page.url
        print(f"[+] Current URL: {current_url}")
        
        if "myaccount.google.com" in current_url or "home" in current_url or "secure" in current_url:
            print("[+] Login successfully!")
        else:
            print("[-] Login failed or requires verification/2FA.")

    except Exception as e:
        print(f"[!] Error: {e}")
        await page.screenshot(path="screenshots/error.png")
    finally:
        await browser.close()

if __name__ == "__main__":
    email = ""
    password = ""
    proxy = None
    headless = True

    for arg in sys.argv[1:]:
        if arg.startswith("--email="):
            email = arg.split("=", 1)[1]
        elif arg.startswith("--password="):
            password = arg.split("=", 1)[1]
        elif arg.startswith("--proxy="):
            proxy = arg.split("=", 1)[1]
        elif arg == "--headed":
            headless = False

    if not email or not password:
        print("Usage: python3 google_login.py --email=your_email --password=your_password [--proxy=socks5://...] [--headed]")
        sys.exit(1)

    asyncio.run(google_login(email, password, headless=headless, proxy=proxy))
