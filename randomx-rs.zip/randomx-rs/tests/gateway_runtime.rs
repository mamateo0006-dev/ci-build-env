use futures_util::{SinkExt, StreamExt};
use nsync_core::crypto;
use serde_json::{json, Value};
use std::process::{Child, Command, Stdio};
use std::time::{Duration, Instant};
use tokio_tungstenite::connect_async;
use tokio_tungstenite::tungstenite::Message;

struct GatewayProcess {
    child: Child,
}

impl Drop for GatewayProcess {
    fn drop(&mut self) {
        let _ = self.child.kill();
        let _ = self.child.wait();
    }
}

async fn wait_for_gateway(url: &str, timeout: Duration) -> bool {
    let start = Instant::now();
    while start.elapsed() < timeout {
        if let Ok((mut ws, _)) = connect_async(url).await {
            let _ = ws.close(None).await;
            return true;
        }
        tokio::time::sleep(Duration::from_millis(100)).await;
    }
    false
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn gateway_accepts_ecdh_handshake() {
    let gateway_bin = env!("CARGO_BIN_EXE_gateway");
    let port = 19090u16;
    let url = format!("ws://127.0.0.1:{}/", port);

    let child = Command::new(gateway_bin)
        .env("NSYNC_GATEWAY_PORT", port.to_string())
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .spawn()
        .expect("spawn gateway binary");
    let _gateway = GatewayProcess { child };

    assert!(wait_for_gateway(&url, Duration::from_secs(5)).await, "gateway did not start");

    let (mut ws, _) = connect_async(&url).await.expect("connect websocket");
    let (secret, public) = crypto::ecdh_generate();
    let hello = json!([0, "ecdh", hex::encode(public)]).to_string();
    let enc_hello = crypto::encrypt_json(&hello, crypto::new_enc_key());
    ws.send(Message::Text(enc_hello)).await.expect("send ecdh hello");

    let reply = tokio::time::timeout(Duration::from_secs(5), ws.next())
        .await
        .expect("gateway reply timeout")
        .expect("gateway closed")
        .expect("gateway message");

    let Message::Text(reply_text) = reply else {
        panic!("expected text reply");
    };

    let plain = crypto::decrypt_json(&reply_text).expect("decrypt gateway ecdh reply");
    let arr: Value = serde_json::from_str(&plain).expect("reply json");
    assert_eq!(arr.get(0).and_then(|v| v.as_str()), Some("ecdh"));
    let peer_hex = arr.get(2).and_then(|v| v.as_str()).expect("peer public key");
    let peer_vec = hex::decode(peer_hex).expect("peer public key hex");
    assert_eq!(peer_vec.len(), 32);

    let mut peer = [0u8; 32];
    peer.copy_from_slice(&peer_vec);
    let session_key = crypto::ecdh_derive(secret, &peer);
    assert_ne!(session_key, [0u8; 32]);
}
