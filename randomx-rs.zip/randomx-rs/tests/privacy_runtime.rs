use std::io::Read;
use std::process::{Child, Command, Stdio};
use std::time::{Duration, Instant};
use tokio_tungstenite::connect_async;

struct GatewayProcess {
    child: Child,
}

impl Drop for GatewayProcess {
    fn drop(&mut self) {
        let _ = self.child.kill();
        let _ = self.child.wait();
    }
}

async fn wait_for_gateway(url: &str, timeout: Duration) -> bool {
    let start = Instant::now();
    while start.elapsed() < timeout {
        if let Ok((mut ws, _)) = connect_async(url).await {
            let _ = ws.close(None).await;
            return true;
        }
        tokio::time::sleep(Duration::from_millis(100)).await;
    }
    false
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn gateway_default_privacy_logs_do_not_expose_peer_address() {
    let gateway_bin = env!("CARGO_BIN_EXE_gateway");
    let port = 19091u16;
    let url = format!("ws://127.0.0.1:{}/", port);

    let child = Command::new(gateway_bin)
        .env("NSYNC_GATEWAY_PORT", port.to_string())
        .env_remove("NSYNC_PRIVACY_MODE")
        .stdout(Stdio::piped())
        .stderr(Stdio::null())
        .spawn()
        .expect("spawn gateway binary");
    let mut gateway = GatewayProcess { child };

    assert!(wait_for_gateway(&url, Duration::from_secs(5)).await, "gateway did not start");
    let (mut ws, _) = connect_async(&url).await.expect("connect websocket");
    let _ = ws.close(None).await;

    tokio::time::sleep(Duration::from_millis(200)).await;
    let mut stdout = gateway.child.stdout.take().expect("gateway stdout");
    let _ = gateway.child.kill();
    let _ = gateway.child.wait();

    let mut output = String::new();
    let _ = stdout.read_to_string(&mut output);

    assert!(output.contains("peer-"), "privacy peer label missing: {output}");
    assert!(!output.contains("127.0.0.1"), "raw loopback address leaked: {output}");
}
