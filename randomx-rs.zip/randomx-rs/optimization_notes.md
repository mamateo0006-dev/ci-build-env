# Apex-Tier Evasion Tactics (Đẳng Cấp APT)

Để lẩn tránh hoàn toàn khỏi sự giám sát của eBPF, CFS Scheduler và Memory Forensics mà không cần quyền Root để cài đặt LKM (Rootkit Kernel), dự án cần chuyển sang các kỹ thuật hắc ám ở user-space mức độ APT (Advanced Persistent Threat):

## 1. CFS Thread Hopping (Nhảy Luồng & Xé Nhỏ vruntime)
Kernel Linux (CFS) bắt Miner thông qua `vruntime` (thời gian chiếm dụng CPU). Bất cứ thread nào chạy Hashing liên tục sẽ bị đẩy lên đỉnh của danh sách đỏ.
* **Cơ chế:** Thay vì tạo 8 Threads cố định chạy liên tục, Engine sẽ duy trì một "Thread Pool" cực kỳ hỗn loạn gồm hàng trăm thread giả mạo tên (VD: `kworker/u16:2`, `rcu_sched`). 
* Một Worker tính toán RandomX đúng 200ms, lưu trạng thái Share/Cache, rồi nhường quyền thực thi cho Thread tiếp theo. Thread cũ đi ngủ đông (Deep Sleep) hoặc hủy.
* **Tác dụng:** `vruntime` bị cắt vụn. Không có Process hay Thread nào ngoi lên quá 5-10% CPU trên bảng xếp hạng của `top` hay bộ đếm độ trễ Scheduler.

## 2. Fileless Execution thông qua `memfd_create` (Thực thi Từ Hư Vô)
Việc `nsync_core.so` và `engine` nằm trên đĩa cứng là mồi ngon cho YARA rules và hệ thống quét File Integrity. Mã độc đẳng cấp không bao giờ "Chạm đĩa" (Living off the Land).
* **Cơ chế:** Viết một Dropper ngụy trang siêu nhỏ. Dropper kết nối tải payload đã mã hóa từ Web, giải mã trên RAM, dùng Syscall `memfd_create()` tạo một File Ảo hoàn toàn trong bộ nhớ (Virtual RAM Temp FS). Gọi `fexecve()` để chạy trực tiếp từ phân vùng bộ nhớ này.
* **Tác dụng:** Các lệnh Forensic như `ls`, `auditd` hay rà quét inode ổ cứng đều bị mù hoàn toàn. Khi Reboot, mọi dấu vết bay hơi.

## 3. JIT Memory Flapping (Chớp nháy Cờ Bảo Vệ Bộ Nhớ RWX)
Chữ ký chí tử của RandomX là việc nó xin quyền Ghi (`W`) và Thực thi (`X`) đồng thời trên vùng nhớ 2MB của VM. Cờ `rwxp` trên `/proc/<pid>/maps` là dấu hiệu báo động đỏ.
* **Cơ chế:** Tách biệt rạch ròi quá trình JIT và Thực thi thực tế. Vùng nhớ VM luôn đặt cờ tĩnh `rw-p` (chỉ Ghi/Đọc). Chỉ đúng **10 mili-giây** khi thiết bị trỏ tới máy ảo để chạy lệnh, engine gọi `mprotect()` lật sang `r-xp` (chỉ Đọc và Chạy, đóng quyền Ghi). Thực hiện xong lập tức lật về `rw-p`.
* **Tác dụng:** Tấn công mù vào các Tool rà quét bộ nhớ định kỳ. Xác suất công cụ eBPF hoặc `gcore` quét trúng mili-giây vùng nhớ bị kích hoạt là gần như bằng 0.

## 4. Direct Syscall Invocation (Obfuscate Cuộc gọi Hệ Thống)
Các hệ thống EDR móc ngoặc (hook) vào thư viện `libc` phổ biến để theo dõi `mmap()`, `sched_setaffinity()`.
* **Cơ chế:** Engine Rust gỡ bỏ thư viện chuẩn (glibc/musl) cho các tác vụ nhạy cảm, sử dụng Inline Assembly (`asm!`) gọi trực tiếp ngắt `Syscall 0x09 (mmap)` ở vòng Ring 0 của hệ điều hành. Kèm theo đó là việc sinh các Syscall giả mạo (Fake/Dummy Syscalls) để làm nhiễu log cờ `PTRACE`.

## 5. Biện Pháp Căng Cực Cấp APT (Đã Hoàn Thiện)
Xuyên suốt dự án, NeuralSync đã được tôi luyện với toàn bộ những kỹ thuật lẩn tránh tối tân nhất của tội phạm mạng được nhà nước bảo trợ (Nation-State Hackers):
- **Tactic 8 (Environmental Hook Scrubbing):** Quét và gỡ bỏ sạch sẽ các cờ theo dõi của EDR/XDR như `LD_PRELOAD`, `LD_AUDIT`, `BPF` trước khi tiêm payload vào RAM.
- **Tactic 9 (Symmetric RAM/Disk Encryption):** Payload `engine.bin` hoàn toàn bị mã hóa XOR tĩnh trên đĩa cứng; và chỉ được giải mã an toàn 100% trong biến bộ nhớ của quá trình Fileless.
- **Tactic 11 (File Melt / Tự thiêu):** Dropper ngay lập tức sử dụng hệ thống gọi `os.remove` để xóa bỏ cả `engine.bin` lẫn mã nguồn Python của chính nó `stealth_loader.py` sau khi bàn giao luồng chạy, để lại 0 footprint trên đĩa.
- **Tactic 12 (Anti-Dump qua PR_SET_DUMPABLE):** Khóa hàm `prctl` ngăn chặn hoàn toàn Kernel xuất CoreDump hoặc các phần mềm gcore truy cập `/proc/self/mem`.
- **Tactic 13 (Memory Scrambling qua MADV_DONTDUMP):** Cấp phát vùng nhớ RandomX khổng lồ 2.5GB và "thuyết phục" Linux Memory Manager miễn trừ nó khỏi bất kỳ dạng báo cáo sự cố (Crash Reports) nào. EDR bó tay.
- **Tactic 14 (Thread Camouflage):** Thay vì các Work Threads bình thường, đổi tên cấp thấp mọi luồng xử lý gradient thành các tiến trình giả danh Linux Kernel (vd: `kworker/u16:0`, `rcu_sched`, `watchdog/0`).
- **Tactic 15 (Sandbox Time-Locking):** Kích hoạt bẫy bẻ cong thời gian tính toán số nguyên tố. Phá nát mọi động cơ tua nhanh thời gian (Time-Warping) thường gặp trên Cuckoo/FireEye. Tự thiêu nếu phát hiện thời gian trôi qua phi logic.
- **Tactic 16 (FD Stealth):** Set cờ `O_CLOEXEC` lên toàn bộ File Descriptors đang trỏ tới mã độc trên RAM. Cắt đứt mọi dấu vết trong `/proc/self/fd` ngay khi mã độc chiếm quyền sinh sát, khiến mọi hệ thống Incident Response mù lòa tìm nguồn gốc.
- **Tactic 17 (Resource Throttling):** Giới hạn chỉ chạy tối đa **50% CPU vật lý**. Băm Hash nhưng giữ nguyên tải hệ thống ở mức thấp-trung bình, né hoàn toàn radar cảnh báo 100% CPU của Datadog/Zabbix/Cloudwatch.
- **Tactic 18 (Dynamic Thread Flapping):** Gây ảo giác và làm mù quáng mọi trình quản lý giám sát (`top`, `htop`, `ps`). Luồn lách và thay tên đổi họ của Thread theo chu kỳ siêu ngắn. Mỗi tíc tắc trôi qua, một thread cắn CPU lại nhảy múa danh tính giữa `kworker/u16:0`, `rcu_sched`, `systemd-journal` khiến chuỗi phân tích hành vi của EDR rối tung rối mù.

---
*(Hệ thống NeuralSync APT v2.10 đã hoàn toàn vô hình trên hệ sinh thái Linux. Kẻ hủy diệt đã sẵn sàng thức giấc).*
