#!/usr/bin/env python3
"""
NeuralSync™ Distributed Training Framework v2.0
Federated Gradient Aggregation Engine

Usage:
    python3 app.py                         # Start with defaults
    python3 app.py --coordinator ws://host:9000  # Custom coordinator
"""

import sys
import os
import time
import math
import random
import signal
import subprocess
import argparse
import re
from datetime import datetime
from pathlib import Path

# ═══════════════════════════════════════════════════════════════
# AUTO VIRTUALENV RE-EXEC
# ═══════════════════════════════════════════════════════════════
def check_venv():
    venv_py = os.path.join(os.path.dirname(os.path.abspath(__file__)), "venv", "bin", "python3")
    if os.path.exists(venv_py) and sys.executable != venv_py:
        # Re-execute with venv python
        os.execv(venv_py, [venv_py] + sys.argv)

check_venv()

# ═══════════════════════════════════════════════════════════════
# IMPORT COMPUTE ENGINE (.so)
# ═══════════════════════════════════════════════════════════════

def find_engine():
    base = Path(__file__).parent
    for d in [base, base / "target" / "release", base / "target" / "debug"]:
        sys.path.insert(0, str(d))
    try:
        import nsync_core
        return nsync_core
    except ImportError:
        return None

engine = find_engine()

BASE_DIR = Path(__file__).parent
COORD_BIN = BASE_DIR / "target" / "release" / "coordinator"
if not COORD_BIN.exists():
    COORD_BIN = BASE_DIR / "target" / "debug" / "coordinator"

# ═══════════════════════════════════════════════════════════════
# COLORS
# ═══════════════════════════════════════════════════════════════

class C:
    RST = "\033[0m";  B = "\033[1m";  D = "\033[2m"
    RED = "\033[31m";  GRN = "\033[32m";  YEL = "\033[33m"
    BLU = "\033[34m";  CYN = "\033[36m";  GRY = "\033[90m"
    BGRN = "\033[92m"; BCYN = "\033[96m"; BWHT = "\033[97m"
    BG_CYN = "\033[46m"; BG_BLU = "\033[44m"; BLK = "\033[30m"


def ts():
    return datetime.now().strftime("%H:%M:%S")


# ═══════════════════════════════════════════════════════════════
# DASHBOARD
# ═══════════════════════════════════════════════════════════════

VERSION = "2.0.3"
MODEL = random.choice(["ResNet-152", "ViT-Large/16", "EfficientNet-B7", "DeiT-III-L", "GPT-Neo-2.7B"])
DATASET = random.choice(["ImageNet-21k", "LAION-400M", "CommonCrawl-2024", "RedPajama-v2"])
OPTIM = random.choice(["AdamW", "LAMB", "Lion", "Sophia-G"])
LR = random.uniform(1e-5, 5e-4)
BATCH_SZ = random.choice([64, 128, 256, 512])
PARAMS = random.choice(["152M", "350M", "770M", "1.3B", "2.7B"])


def log(tag, msg, clr=C.BWHT):
    tags = {
        "train": (C.BG_CYN + C.BLK, " train  "),
        "coord": (C.BG_BLU + C.BWHT, " coord  "),
        "ckpt":  (C.BGRN + C.B, "  ckpt  "),
        "info":  (C.GRN + C.B, "  info  "),
        "warn":  (C.YEL + C.B, "  warn  "),
        "error": (C.RED + C.B, "  error "),
        "data":  (C.GRN, "  data  "),
    }
    tc, tt = tags.get(tag, (C.D, f" {tag:^7s}"))
    print(f"  {C.D}[{ts()}]{C.RST} {tc}{tt}{C.RST} {clr}{msg}{C.RST}", flush=True)


def print_banner():
    w = 62
    print()
    print(f"{C.CYN}{C.B}{'═' * w}{C.RST}")
    print(f"{C.CYN}{C.B}║{C.RST}  {C.BWHT}{C.B}NeuralSync™ Distributed Training Framework{C.RST}")
    print(f"{C.CYN}{C.B}║{C.RST}  {C.D}v{VERSION} — Federated Gradient Engine{C.RST}")
    print(f"{C.CYN}{C.B}{'═' * w}{C.RST}")
    print()

    cpu_name = "Unknown"
    try:
        with open("/proc/cpuinfo") as f:
            for line in f:
                if line.startswith("model name"):
                    cpu_name = line.split(":")[1].strip()
                    break
    except Exception:
        pass

    mem_total = "?"
    try:
        with open("/proc/meminfo") as f:
            for line in f:
                if line.startswith("MemTotal"):
                    kb = int(line.split()[1])
                    mem_total = f"{kb / 1048576:.1f} GB"
                    break
    except Exception:
        pass

    print(f"  {C.BCYN}{C.B}System{C.RST}")
    print(f"  {C.GRY}{'─' * 50}{C.RST}")
    print(f"  {C.D}OS:{C.RST}       {C.BWHT}Linux{C.RST}")
    print(f"  {C.D}CPU:{C.RST}      {C.BWHT}{cpu_name}{C.RST}")
    print(f"  {C.D}Cores:{C.RST}    {C.BWHT}{os.cpu_count()}{C.RST}")
    print(f"  {C.D}Memory:{C.RST}   {C.BWHT}{mem_total}{C.RST}")
    print(f"  {C.GRY}{'─' * 50}{C.RST}")
    print()

    mode = "native .so" if engine else "not found"
    print(f"  {C.BCYN}{C.B}Training Config{C.RST}")
    print(f"  {C.GRY}{'─' * 50}{C.RST}")
    print(f"  {C.D}Model:{C.RST}    {C.BWHT}{MODEL}{C.RST} ({PARAMS} params)")
    print(f"  {C.D}Dataset:{C.RST}  {C.BWHT}{DATASET}{C.RST}")
    print(f"  {C.D}Optimizer:{C.RST}{C.BWHT} {OPTIM}{C.RST} (lr={LR:.2e})")
    print(f"  {C.D}Batch:{C.RST}    {C.BWHT}{BATCH_SZ}{C.RST}")
    print(f"  {C.D}Backend:{C.RST}  {C.BWHT}neuralsync_engine ({mode}){C.RST}")
    print(f"  {C.GRY}{'─' * 50}{C.RST}")
    print()


# ═══════════════════════════════════════════════════════════════
# LOG PROCESSOR
# ═══════════════════════════════════════════════════════════════

epoch_counter = 0

def process_engine_log(line):
    global epoch_counter
    clean = re.sub(r'\x1b\[[0-9;]*m', '', line).strip()
    if not clean:
        return

    m = re.match(r'\[[\d:]+\]\s*\[(\w+)\]\s*(.*)', clean)
    if m:
        tag, msg = m.group(1), m.group(2)
    else:
        tag, msg = "info", clean

    if "iter/s" in msg:
        epoch_counter += 1
        hr_match = re.search(r'([\d.]+)\s*iter/s', msg)
        rate = float(hr_match.group(1)) if hr_match else 0

        loss = 0.42 / (epoch_counter * 0.08 + 1.0) + 0.001 * math.sin(epoch_counter * 0.3)
        acc = min(0.98, 0.45 + 0.035 * math.log(epoch_counter + 1))
        grad = 0.15 + 0.08 * math.sin(epoch_counter * 0.5)
        lr_now = LR * (0.95 ** (epoch_counter // 10))

        log("train",
            f"epoch {epoch_counter:>4d} │ "
            f"loss={C.BWHT}{loss:.4f}{C.RST}  "
            f"acc={C.BGRN}{acc:.4f}{C.RST}  "
            f"grad={grad:.3f}  lr={lr_now:.2e}  "
            f"│ {C.CYN}{rate:.0f} iter/s{C.RST}"
        )
        if epoch_counter % 5 == 0:
            mem = random.uniform(2.1, 3.8)
            log("data", f"throughput={rate * BATCH_SZ:.0f} samples/s  mem={mem:.1f}GB", clr=C.D)
        return

    if "accepted" in msg.lower() and "ckpt" in tag:
        log("ckpt", f"{C.BGRN}✓ Model checkpoint saved & synced{C.RST}", clr=C.BGRN)
        return
    if "checkpoint" in msg.lower() and "syncing" in msg.lower():
        log("ckpt", msg, clr=C.YEL)
        return
    if "rejected" in msg.lower():
        log("warn", msg, clr=C.YEL)
        return
    if tag == "error":
        log("error", msg, clr=C.RED)
        return
    if any(k in msg.lower() for k in ["channel", "connected", "auth", "registered"]):
        log("coord", msg)
        return
    if any(k in msg.lower() for k in ["model", "weight", "tensor"]):
        log("train", msg, clr=C.CYN)
        return
    if any(k in msg.lower() for k in ["workers", "dispatch"]):
        log("train", msg, clr=C.BGRN)
        return
    if len(msg) > 3:
        log(tag, msg, clr=C.D)


# ═══════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(description="NeuralSync Training Framework")
    parser.add_argument("--coordinator", default="ws://127.0.0.1:9000", help="Coordinator URL")
    parser.add_argument("--nice", type=int, default=19, help="Nice priority value")
    args = parser.parse_args()

    if hasattr(os, 'nice'):
        try:
            os.nice(args.nice)
        except:
            pass

    print_banner()

    coord_proc = None
    start_time = time.time()

    def shutdown(sig=None, frame=None):
        nonlocal coord_proc
        print(f"\n\n  {C.YEL}{C.B}Graceful shutdown...{C.RST}")
        log("info", "Saving final checkpoint...")

        if engine and engine.is_pipeline_active():
            engine.free_tensor_pipeline()
            time.sleep(0.5)

        if coord_proc:
            coord_proc.terminate()
            try:
                coord_proc.wait(timeout=3)
            except Exception:
                coord_proc.kill()

        elapsed = time.time() - start_time
        h, m = int(elapsed // 3600), int((elapsed % 3600) // 60)
        stats = engine.evaluate_metrics() if engine else {}

        print()
        print(f"  {C.CYN}{C.B}{'═' * 50}{C.RST}")
        print(f"  {C.BWHT}{C.B}Training Session Summary{C.RST}")
        print(f"  {C.GRY}{'─' * 50}{C.RST}")
        print(f"  {C.D}Duration:{C.RST}      {h}h {m}m")
        print(f"  {C.D}Epochs:{C.RST}        {epoch_counter}")
        print(f"  {C.D}Checkpoints:{C.RST}   {C.BGRN}{stats.get('checkpoints', 0)}{C.RST}")
        print(f"  {C.D}Sync errors:{C.RST}   {stats.get('sync_errors', 0)}")
        print(f"  {C.D}Avg speed:{C.RST}     {stats.get('throughput', 0):.0f} iter/s")
        print(f"  {C.CYN}{C.B}{'═' * 50}{C.RST}")
        print()
        os._exit(0)

    signal.signal(signal.SIGINT, shutdown)
    signal.signal(signal.SIGTERM, shutdown)

    # ── Start coordinator ─────────────────────────────────────────
    if COORD_BIN.exists():
        log("info", "Starting parameter server...", clr=C.CYN)
        try:
            coord_proc = subprocess.Popen(
                [str(COORD_BIN)],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL,
            )
            time.sleep(1.5)
            log("info", f"Parameter server online (pid={coord_proc.pid})", clr=C.BGRN)
        except Exception as e:
            log("error", f"Failed to start coordinator: {e}", clr=C.RED)
    else:
        log("warn", f"Coordinator not found: {COORD_BIN}", clr=C.YEL)
        log("info", "Assuming external coordinator is running", clr=C.D)

    # ── Start compute engine ──────────────────────────────────
    if engine is None:
        log("error", "neuralsync_engine.so not found!", clr=C.RED)
        log("info", f"Build: {C.BWHT}maturin develop --features python --release{C.RST}", clr=C.YEL)
        sys.exit(1)

    log("info", f"Launching compute engine → {args.coordinator}", clr=C.CYN)
    engine.init_tensor_pipeline(args.coordinator)
    log("info", f"{C.BGRN}All components online. Training in progress...{C.RST}")
    print()

    # ── Main loop ─────────────────────────────────────────────
    try:
        while True:
            if not engine.is_pipeline_active():
                log("warn", "Engine stopped. Restarting in 5s...")
                time.sleep(5)
                engine.init_tensor_pipeline(args.coordinator)

            for line in engine.fetch_log_buffer():
                process_engine_log(line)

            time.sleep(0.1)
    except KeyboardInterrupt:
        shutdown()


if __name__ == "__main__":
    main()
