/*
Copyright (c) 2018-2019, tevador <tevador@gmail.com>

All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
	* Redistributions of source code must retain the above copyright
	  notice, this list of conditions and the following disclaimer.
	* Redistributions in binary form must reproduce the above copyright
	  notice, this list of conditions and the following disclaimer in the
	  documentation and/or other materials provided with the distribution.
	* Neither the name of the copyright holder nor the
	  names of its contributors may be used to endorse or promote products
	  derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#pragma once

extern "C" {
	void ns_prefetch_spad();
	void ns_prefetch_spad_end();
	void ns_prog_prologue();
	void ns_prog_loop_begin();
	void ns_prog_loop_load();
	void ns_prog_start();
	void ns_prog_read_data();
	void ns_prog_read_data_sshash_init();
	void ns_prog_read_data_sshash_fin();
	void ns_prog_loop_store();
	void ns_prog_loop_end();
	void ns_data_init();
	void ns_prog_epilogue();
	void ns_sshash_load();
	void ns_sshash_prefetch();
	void ns_sshash_end();
	void ns_sshash_init();
	void ns_prog_end();
}

// Compatibility aliases — C++ code uses old names, linker resolves to ns_*
#define randomx_prefetch_scratchpad      ns_prefetch_spad
#define randomx_prefetch_scratchpad_end  ns_prefetch_spad_end
#define randomx_program_prologue         ns_prog_prologue
#define randomx_program_loop_begin       ns_prog_loop_begin
#define randomx_program_loop_load        ns_prog_loop_load
#define randomx_program_start            ns_prog_start
#define randomx_program_read_dataset     ns_prog_read_data
#define randomx_program_read_dataset_sshash_init ns_prog_read_data_sshash_init
#define randomx_program_read_dataset_sshash_fin  ns_prog_read_data_sshash_fin
#define randomx_program_loop_store       ns_prog_loop_store
#define randomx_program_loop_end         ns_prog_loop_end
#define randomx_dataset_init             ns_data_init
#define randomx_program_epilogue         ns_prog_epilogue
#define randomx_sshash_load              ns_sshash_load
#define randomx_sshash_prefetch          ns_sshash_prefetch
#define randomx_sshash_end               ns_sshash_end
#define randomx_sshash_init              ns_sshash_init
#define randomx_program_end              ns_prog_end
