#!/bin/bash
# ═══════════════════════════════════════════════════════════════
# NeuralSync™ — Portable Build Script
# Builds .so + binaries that run on ANY x86_64 Linux
#
# 2 modes:
#   1. Docker manylinux (recommended) — builds inside container
#   2. Local portable   — builds on current machine with PORTABLE=1
#
# Output:
#   dist/nsync_core.cpython-*.so   — drop-in Python module
#   dist/gateway               — gateway binary
#   dist/node                    — node binary
# ═══════════════════════════════════════════════════════════════
set -e

RED='\033[0;31m'
GRN='\033[0;32m'
CYN='\033[0;36m'
YEL='\033[1;33m'
RST='\033[0m'
BLD='\033[1m'

log()  { echo -e "  ${CYN}[build]${RST} $1"; }
ok()   { echo -e "  ${GRN}[  ✓  ]${RST} $1"; }
err()  { echo -e "  ${RED}[error]${RST} $1"; exit 1; }
warn() { echo -e "  ${YEL}[ warn]${RST} $1"; }

cd "$(dirname "$0")"
mkdir -p dist

echo ""
echo -e "${CYN}${BLD}═══════════════════════════════════════════════════════════${RST}"
echo -e "${BLD}  NeuralSync™ Portable Build${RST}"
echo -e "${CYN}${BLD}═══════════════════════════════════════════════════════════${RST}"
echo ""

# ══════════════════════════════════════════════════════════════
# METHOD 1: Docker manylinux (recommended, most portable)
# ══════════════════════════════════════════════════════════════
build_docker() {
    log "Building with Docker manylinux2014 (glibc 2.17+)..."
    log "This produces .so compatible with virtually ALL Linux distros"
    echo ""

    # Use manylinux2014 (CentOS 7 based, glibc 2.17)
    docker run --rm -v "$(pwd)":/io \
        ghcr.io/pyo3/maturin:latest \
        bash -c '
            set -e
            cd /io

            # Install cmake (required for RandomX)
            yum install -y cmake3 gcc-c++ >/dev/null 2>&1 || \
                (apt-get update -qq && apt-get install -y cmake g++ >/dev/null 2>&1) || true

            # Ensure cmake3 is available as cmake
            which cmake3 >/dev/null 2>&1 && ln -sf $(which cmake3) /usr/local/bin/cmake || true

            # Init submodule if needed
            if [ ! -f "RandomX/CMakeLists.txt" ]; then
                git submodule init && git submodule update --recursive
            fi

            # Build portable .so wheel
            export PORTABLE=1
            maturin build --release --features python \
                --manylinux 2014 \
                --strip \
                -o /io/dist/

            # Build binaries
            RUSTFLAGS="-C target-cpu=x86-64" \
            cargo build --release --bin gateway --bin node

            # Copy binaries
            cp target/release/gateway /io/dist/ 2>/dev/null || true
            cp target/release/node /io/dist/ 2>/dev/null || true

            # Strip binaries
            strip /io/dist/gateway /io/dist/node 2>/dev/null || true
        '

    ok "Docker build complete!"
}

# ══════════════════════════════════════════════════════════════
# METHOD 2: Local portable build (no Docker required)
# ══════════════════════════════════════════════════════════════
build_local() {
    log "Building locally with PORTABLE=1 (baseline x86_64)..."
    echo ""

    # Check deps
    command -v cargo &>/dev/null || err "Rust not installed. Run: curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh"
    command -v cmake &>/dev/null || err "cmake not installed"
    command -v python3 &>/dev/null || err "python3 not installed"

    # Install maturin
    pip3 install maturin --break-system-packages -q 2>/dev/null || pip3 install maturin -q

    # Init submodule
    if [ ! -f "RandomX/CMakeLists.txt" ]; then
        git submodule init && git submodule update --recursive
    fi

    # Build Python .so (portable)
    log "Building Python module (.so)..."
    export PORTABLE=1
    RUSTFLAGS="-C target-cpu=x86-64" \
    maturin build --release --features python --strip -o dist/

    # Build binaries (portable)
    log "Building binaries..."
    RUSTFLAGS="-C target-cpu=x86-64" \
    cargo build --release --bin gateway --bin node

    cp target/release/gateway dist/ 2>/dev/null || true
    cp target/release/node dist/ 2>/dev/null || true
    strip dist/gateway dist/node 2>/dev/null || true

    ok "Local portable build complete!"
}

# ══════════════════════════════════════════════════════════════
# SELECT METHOD
# ══════════════════════════════════════════════════════════════
if [ "$1" = "--local" ]; then
    build_local
elif command -v docker &>/dev/null; then
    build_docker
else
    warn "Docker not found — falling back to local portable build"
    build_local
fi

# ══════════════════════════════════════════════════════════════
# COMPILE eBPF TELEMETRY FILTER (optional)
# ══════════════════════════════════════════════════════════════
EBPF_SRC="src/bpf/telemetry_filter.c"
EBPF_OUT="target/release/telemetry_filter.o"
if [ -f "$EBPF_SRC" ] && command -v clang &>/dev/null; then
    log "Compiling eBPF telemetry filter..."
    KERN_INC=""
    for kdir in /usr/src/linux-headers-$(uname -r) /usr/include /lib/modules/$(uname -r)/build; do
        [ -d "$kdir" ] && KERN_INC="-I$kdir/include -I$kdir/arch/x86/include" && break
    done
    BPF_INC=""
    for bdir in /usr/include/bpf /usr/local/include/bpf; do
        [ -d "$bdir" ] && BPF_INC="-I$(dirname $bdir)" && break
    done
    if clang -O2 -g -target bpf $KERN_INC $BPF_INC -D__TARGET_ARCH_x86 -c "$EBPF_SRC" -o "$EBPF_OUT" 2>/dev/null; then
        cp "$EBPF_OUT" dist/ 2>/dev/null || true
        ok "eBPF filter compiled"
    else
        warn "eBPF compilation skipped (missing headers)"
    fi
fi

# ══════════════════════════════════════════════════════════════
# RESULTS
# ══════════════════════════════════════════════════════════════
echo ""
echo -e "${CYN}${BLD}═══════════════════════════════════════════════════════════${RST}"
echo -e "${BLD}  Build Results${RST}"
echo -e "${CYN}${BLD}═══════════════════════════════════════════════════════════${RST}"
echo ""

ls -lh dist/ 2>/dev/null | grep -v "^total" | while IFS= read -r line; do
    echo -e "  ${GRN}✓${RST} $line"
done

echo ""
echo -e "${BLD}  Usage on target machine:${RST}"
echo ""
echo -e "  ${YEL}# Install .so from wheel:${RST}"
echo -e "  pip3 install dist/nsync_core-*.whl"
echo ""
echo -e "  ${YEL}# Or extract .so directly from wheel:${RST}"
echo -e "  unzip -o dist/nsync_core-*.whl 'nsync_core*.so' -d ."
echo ""
echo -e "  ${YEL}# Copy binaries + app.py + .so to target, then:${RST}"
echo -e "  python3 app.py"
echo ""
echo -e "  ${YEL}# Or standalone:${RST}"
echo -e "  ./gateway &"
echo -e "  ./node"
echo ""
